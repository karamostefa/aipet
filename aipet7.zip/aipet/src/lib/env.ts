// ------------------------------------------------------------------
// Fails LOUD, not silent. Imported once from src/lib/db.ts (so it runs
// on essentially every server request) and checks that required
// configuration is actually present. This exists because the single
// most common cause of "the signup form did nothing" is a missing or
// wrong DATABASE_URL — previously that just threw an unhandled
// exception deep in a route handler with no clear signal anywhere.
//
// This does NOT crash the process — a partially-configured app should
// still boot so you can fix env vars without redeploying blind — it
// just makes the problem impossible to miss in your server logs.
// ------------------------------------------------------------------

let didCheck = false;

const PLACEHOLDER_MARKERS = ['xxxxxxxx', 'replace-with', 'user:password@host'];

function looksLikePlaceholder(value: string | undefined): boolean {
  if (!value) return true;
  return PLACEHOLDER_MARKERS.some((marker) => value.includes(marker));
}

export function checkEnv() {
  if (didCheck) return;
  didCheck = true;

  const problems: string[] = [];

  if (looksLikePlaceholder(process.env.DATABASE_URL)) {
    problems.push(
      'DATABASE_URL is missing or still the .env.example placeholder — every DB read/write (signups, ' +
        'logins, admin content, everything) will fail. Set it to a real PostgreSQL connection string. ' +
        'On Supabase specifically, use the pooled connection string, not "Direct connection" — see the ' +
        'README\'s "Connecting to Supabase" section if you hit error P1001.'
    );
  }
  if (looksLikePlaceholder(process.env.DIRECT_URL)) {
    problems.push(
      'DIRECT_URL is missing or still the .env.example placeholder — `npm run db:push` / `db:migrate` ' +
        'will fail even if DATABASE_URL is fine, since Prisma requires it for schema changes.'
    );
  }
  if (looksLikePlaceholder(process.env.JWT_SECRET)) {
    problems.push(
      'JWT_SECRET is missing or still the .env.example placeholder — sessions will not verify correctly. ' +
        'Generate one with: openssl rand -base64 32'
    );
  }
  if (looksLikePlaceholder(process.env.ANTHROPIC_API_KEY)) {
    problems.push(
      'ANTHROPIC_API_KEY is not set — AIPeT will run in DEMO MODE (canned tutoring replies, clearly ' +
        'labelled) instead of real AI analysis. Set a real key from console.anthropic.com before launch.'
    );
  }
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) {
    problems.push(
      'SMTP_HOST/SMTP_USER are not set — activation emails will fail to send (the account is still ' +
        'created; check /admin/aipet/students to get the activation link manually until this is fixed).'
    );
  }
  if (looksLikePlaceholder(process.env.CHARGILY_SECRET_KEY)) {
    problems.push(
      'CHARGILY_SECRET_KEY is not set — students can use their free trial, but subscribing after it ' +
        'ends will fail until this is configured.'
    );
  }

  if (problems.length > 0) {
    console.warn('\n⚠️  AIPeT configuration warnings (fix in .env):');
    for (const p of problems) console.warn('   • ' + p);
    console.warn('');
  }
}
