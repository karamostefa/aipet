// ------------------------------------------------------------------
// Mathpix OCR — turns a photo of handwritten math into text/LaTeX.
// Get an App ID + App Key at https://mathpix.com (free tier available,
// paid tiers scale with volume — see the pricing note in the README).
// ------------------------------------------------------------------

interface OcrResult {
  text: string;
  confidence: number;
}

export async function runMathpixOcr(base64DataUrl: string): Promise<OcrResult> {
  const appId = process.env.MATHPIX_APP_ID;
  const appKey = process.env.MATHPIX_APP_KEY;

  if (!appId || !appKey) {
    // No OCR configured yet — fail loudly so the caller can fall back to
    // manual transcription instead of silently sending garbage to the tutor.
    throw new Error('MATHPIX_NOT_CONFIGURED');
  }

  const res = await fetch('https://api.mathpix.com/v3/text', {
    method: 'POST',
    headers: {
      app_id: appId,
      app_key: appKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      src: base64DataUrl,
      formats: ['text'],
      data_options: { include_asciimath: true },
    }),
  });

  if (!res.ok) {
    throw new Error(`Mathpix request failed (${res.status}): ${await res.text()}`);
  }

  const data = await res.json();
  return {
    text: data.text || '',
    confidence: data.confidence ?? 0,
  };
}
