'use client';

import { useRef, useState } from 'react';
import type { Locale } from '@/i18n/config';

interface TutorMessage {
  role: 'student' | 'tutor';
  content: string;
  at: string;
}

export default function ExercisePractice({ locale, exerciseId }: { locale: Locale; exerciseId: string }) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mode, setMode] = useState<'photo' | 'type'>('photo');
  const [manualText, setManualText] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const [submissionId, setSubmissionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<TutorMessage[]>([]);
  const [reply, setReply] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const t = {
    photoTab: locale === 'ar' ? 'صوّر حلّي' : 'Photograph my work',
    typeTab: locale === 'ar' ? 'اكتب حلّي' : 'Type my work',
    upload: locale === 'ar' ? 'اختر صورة' : 'Choose photo',
    typePlaceholder: locale === 'ar' ? 'اكتب هنا خطوات حلّك...' : 'Type out your solution steps here...',
    submit: locale === 'ar' ? 'أرسل للتحليل' : 'Submit for analysis',
    replyPlaceholder: locale === 'ar' ? 'اكتب ردك أو سؤالك...' : 'Type your reply or question...',
    send: locale === 'ar' ? 'إرسال' : 'Send',
    analyzing: locale === 'ar' ? 'AIPeT يحلل عملك...' : 'AIPeT is analyzing your work...',
  };

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  async function handleSubmit() {
    if (mode === 'photo' && !preview) return;
    if (mode === 'type' && !manualText.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/aipet/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exerciseId,
          imageBase64: mode === 'photo' ? preview : null,
          manualText: mode === 'type' ? manualText : null,
          locale,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong.');
      setSubmissionId(data.submissionId);
      setMessages(data.messages);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  async function handleReply() {
    if (!reply.trim() || !submissionId) return;
    const studentMsg: TutorMessage = { role: 'student', content: reply, at: new Date().toISOString() };
    setMessages((m) => [...m, studentMsg]);
    setReply('');
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/aipet/submissions/${submissionId}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: studentMsg.content, locale }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong.');
      setMessages(data.messages);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  const [resolved, setResolved] = useState(false);

  async function handleMarkSolved() {
    if (!submissionId) return;
    await fetch(`/api/aipet/submissions/${submissionId}/complete`, { method: 'POST' });
    setResolved(true);
  }

  if (submissionId) {
    return (
      <div className="mt-8">
        <div className="space-y-4">
          {messages.map((m, i) => (
            <div key={i} className={`max-w-[85%] rounded-brand p-4 text-sm ${m.role === 'tutor' ? 'bg-violet-500/10 text-mist-200' : 'ml-auto bg-teal-500/10 text-white'}`}>
              <p className="mb-1 text-xs font-semibold uppercase tracking-wide opacity-60">
                {m.role === 'tutor' ? 'AIPeT' : locale === 'ar' ? 'أنت' : 'You'}
              </p>
              <p className="whitespace-pre-line">{m.content}</p>
            </div>
          ))}
          {loading && <p className="text-sm text-mist-400">{t.analyzing}</p>}
        </div>
        {resolved ? (
          <p className="mt-6 rounded-lg border border-teal-500/30 bg-teal-500/10 p-4 text-teal-300">
            {locale === 'ar' ? 'أحسنت! تم تسجيل هذا التمرين كمُتقَن.' : "Nicely done! This exercise is now marked as mastered."}
          </p>
        ) : (
          <div className="mt-6 flex gap-3">
            <input value={reply} onChange={(e) => setReply(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleReply()}
              placeholder={t.replyPlaceholder}
              className="flex-1 rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
            <button onClick={handleReply} disabled={loading} className="btn-primary disabled:opacity-60">{t.send}</button>
          </div>
        )}
        {!resolved && (
          <button onClick={handleMarkSolved} className="mt-3 text-sm text-teal-400 hover:text-teal-300">
            {locale === 'ar' ? '✓ لقد حللت هذا التمرين الآن' : "✓ I've solved this exercise now"}
          </button>
        )}
        {error && <p className="mt-3 text-sm text-red-400">{error}</p>}
      </div>
    );
  }

  return (
    <div className="mt-8">
      <div className="mb-4 flex gap-2">
        <button onClick={() => setMode('photo')} className={`rounded-full px-4 py-1.5 text-sm ${mode === 'photo' ? 'bg-teal-500/20 text-teal-300' : 'text-mist-400'}`}>{t.photoTab}</button>
        <button onClick={() => setMode('type')} className={`rounded-full px-4 py-1.5 text-sm ${mode === 'type' ? 'bg-teal-500/20 text-teal-300' : 'text-mist-400'}`}>{t.typeTab}</button>
      </div>

      {mode === 'photo' ? (
        <div>
          <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handleFileChange} className="hidden" />
          <button onClick={() => fileInputRef.current?.click()} className="btn-secondary">{t.upload}</button>
          {preview && (
            <div className="mt-4 max-w-xs overflow-hidden rounded-brand border border-white/10">
              <img src={preview} alt="" className="w-full" />
            </div>
          )}
        </div>
      ) : (
        <textarea rows={6} value={manualText} onChange={(e) => setManualText(e.target.value)} placeholder={t.typePlaceholder}
          className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
      )}

      {error && <p className="mt-3 text-sm text-red-400">{error}</p>}

      <button onClick={handleSubmit} disabled={loading} className="btn-primary mt-6 disabled:opacity-60">
        {loading ? t.analyzing : t.submit}
      </button>
    </div>
  );
}
