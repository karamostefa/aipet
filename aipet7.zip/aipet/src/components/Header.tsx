import Link from 'next/link';
import type { Locale } from '@/i18n/config';
import type { Dictionary } from '@/i18n/getDictionary';

export default function Header({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const otherLocale = locale === 'en' ? 'ar' : 'en';

  return (
    <header className="border-b border-white/5 bg-ink-950/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4 md:px-10">
        <Link href={`/${locale}`} className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-gold-500 to-teal-600 font-display text-sm font-bold text-ink-950">
            AT
          </span>
          <span className="font-display text-lg font-semibold text-white">AIPeT</span>
        </Link>

        <nav className="flex items-center gap-6 text-sm text-mist-400">
          <Link href={`/${locale}/aipet/dashboard`} className="hover:text-white">
            {dict.nav.dashboard}
          </Link>
          <Link href={`/${locale}/aipet/login`} className="hover:text-white">
            {dict.nav.login}
          </Link>
          <Link
            href={`/${otherLocale}`}
            className="rounded-full border border-white/10 px-3 py-1.5 text-xs hover:border-teal-500 hover:text-teal-400"
          >
            {dict.common.switchLang}
          </Link>
        </nav>
      </div>
    </header>
  );
}
