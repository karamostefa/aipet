import { prisma } from '@/lib/db';
import Link from 'next/link';

export default async function AdminDashboardPage() {
  const [
    moduleCount,
    unitCount,
    exerciseCount,
    activeStudents,
    trialingStudents,
    submissionCount,
    resolvedCount,
    paidPayments,
  ] = await Promise.all([
    prisma.aipetModule.count(),
    prisma.aipetUnit.count(),
    prisma.aipetExercise.count(),
    prisma.aipetSubscriber.count({ where: { subscriptionStatus: 'ACTIVE' } }),
    prisma.aipetSubscriber.count({ where: { subscriptionStatus: 'TRIALING' } }),
    prisma.submission.count(),
    prisma.submission.count({ where: { status: 'RESOLVED' } }),
    prisma.aipetPayment.findMany({ where: { status: 'PAID' }, select: { amountDzd: true } }),
  ]);

  const totalRevenueDzd = paidPayments.reduce((sum, p) => sum + Number(p.amountDzd), 0);

  const cards = [
    { label: 'Modules', value: moduleCount, href: '/admin/aipet/modules' },
    { label: 'Units', value: unitCount, href: '/admin/aipet/units' },
    { label: 'Exercises', value: exerciseCount, href: '/admin/aipet/exercises' },
    { label: 'Paid subscribers', value: activeStudents, href: '/admin/aipet/students' },
    { label: 'On free trial', value: trialingStudents, href: '/admin/aipet/students' },
    { label: 'Total revenue (DZD)', value: totalRevenueDzd.toLocaleString(), href: '/admin/aipet/payments' },
    { label: 'Total submissions', value: submissionCount, href: '#' },
    { label: 'Exercises resolved', value: resolvedCount, href: '#' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Dashboard</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className="rounded-brand border border-white/10 bg-white/[0.03] p-6 transition hover:border-teal-600/40">
            <p className="text-3xl font-semibold text-white">{c.value}</p>
            <p className="mt-1 text-sm text-mist-400">{c.label}</p>
          </Link>
        ))}
      </div>
      <p className="mt-8 text-sm text-mist-400">
        Start by adding a Module (e.g. &quot;Mathematics&quot;), then Units inside it (e.g. &quot;Sequences&quot;),
        then Exercises inside each unit. Only PUBLISHED items are visible to students.
      </p>
    </div>
  );
}
