import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireActiveStudent } from '@/lib/subscription';
import { checkRateLimit } from '@/lib/security';
import { uploadImage } from '@/lib/storage';
import { runMathpixOcr } from '@/lib/ocr';
import { analyzeInitialSubmission, type TutorMessage } from '@/lib/tutor';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  exerciseId: z.string().uuid(),
  imageBase64: z.string().nullable().optional(),
  manualText: z.string().max(8000).nullable().optional(),
  locale: z.enum(['en', 'ar']).default('en'),
});

// Base64 inflates size by ~33% — 12MB of base64 text is roughly an 9MB
// photo, generous for a phone camera shot while still capping how much
// any single request can force the server to hold in memory/disk.
const MAX_IMAGE_BASE64_CHARS = 12_000_000;

async function postHandler(req: NextRequest) {
  const student = await requireActiveStudent();
  if (!student) return NextResponse.json({ error: 'Please log in or subscribe to continue.' }, { status: 401 });

  const limited = await checkRateLimit(req, 'form');
  if (limited) return limited;

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const { exerciseId, imageBase64, manualText, locale } = parsed.data;
  if (!imageBase64 && !manualText) {
    return NextResponse.json({ error: 'Please provide a photo or type your work.' }, { status: 400 });
  }
  if (imageBase64 && imageBase64.length > MAX_IMAGE_BASE64_CHARS) {
    return NextResponse.json({ error: 'That photo is too large. Please retake it at a lower resolution.' }, { status: 413 });
  }

  const exercise = await prisma.aipetExercise.findUnique({ where: { id: exerciseId } });
  if (!exercise || exercise.status !== 'PUBLISHED') {
    return NextResponse.json({ error: 'Exercise not found.' }, { status: 404 });
  }

  // --- Get the student's work as text, either via OCR or direct typing ---
  let studentWork: string;
  let imageUrl = '';

  if (imageBase64) {
    imageUrl = await uploadImage(imageBase64, 'submission');
    try {
      const ocr = await runMathpixOcr(imageBase64);
      studentWork = ocr.text;
      if (!studentWork.trim()) throw new Error('OCR_EMPTY');
    } catch {
      return NextResponse.json(
        {
          error:
            'We could not read that photo clearly (or OCR is not yet configured). Please retake the photo in better lighting, or switch to "Type my work" instead.',
        },
        { status: 422 }
      );
    }
  } else {
    studentWork = manualText!;
  }

  // --- Ask AIPeT to analyze it ---
  let tutorReply: string;
  try {
    tutorReply = await analyzeInitialSubmission(
      {
        statement: locale === 'ar' ? exercise.statementAr : exercise.statementEn,
        officialSolution: locale === 'ar' ? exercise.officialSolutionAr : exercise.officialSolutionEn,
        solutionSteps: locale === 'ar' ? exercise.solutionStepsAr : exercise.solutionStepsEn,
        keyConcepts: locale === 'ar' ? exercise.keyConceptsAr : exercise.keyConceptsEn,
        commonMistakes: locale === 'ar' ? exercise.commonMistakesAr : exercise.commonMistakesEn,
      },
      studentWork,
      locale
    );
  } catch (err) {
    console.error('AIPeT analysis failed:', err);
    return NextResponse.json(
      { error: 'AIPeT could not analyze your work right now (the AI tutor may not be configured yet). Please try again shortly.' },
      { status: 502 }
    );
  }

  const submission = await prisma.submission.create({
    data: {
      studentId: student.id,
      exerciseId,
      imageUrl: imageUrl || 'text-only',
      ocrText: studentWork,
      status: 'IN_PROGRESS',
    },
  });

  const messages: TutorMessage[] = [{ role: 'tutor', content: tutorReply, at: new Date().toISOString() }];
  await prisma.tutorSession.create({
    data: {
      submissionId: submission.id,
      studentId: student.id,
      messages: messages as unknown as object[],
    },
  });

  // First attempt at this exercise? Bump the unit's "attempted" count.
  await recomputeProgress(student.id, exercise.unitId);

  return NextResponse.json({ submissionId: submission.id, messages });
}

async function recomputeProgress(studentId: string, unitId: string) {
  const exercises = await prisma.aipetExercise.findMany({ where: { unitId, status: 'PUBLISHED' }, select: { id: true } });
  const exerciseIds = exercises.map((e) => e.id);
  const submissions = await prisma.submission.findMany({
    where: { studentId, exerciseId: { in: exerciseIds } },
    select: { exerciseId: true, score: true },
  });
  const attemptedExercises = new Set(submissions.map((s) => s.exerciseId));
  const masteredExercises = new Set(submissions.filter((s) => (s.score ?? 0) >= 70).map((s) => s.exerciseId));
  const scores = submissions.filter((s) => s.score != null).map((s) => s.score!) as number[];
  const averageScore = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

  await prisma.progress.upsert({
    where: { studentId_unitId: { studentId, unitId } },
    update: {
      exercisesAttempted: attemptedExercises.size,
      exercisesMastered: masteredExercises.size,
      averageScore,
      lastActivityAt: new Date(),
    },
    create: {
      studentId,
      unitId,
      exercisesAttempted: attemptedExercises.size,
      exercisesMastered: masteredExercises.size,
      averageScore,
      lastActivityAt: new Date(),
    },
  });
}

export const POST = withApiHandler(postHandler);
