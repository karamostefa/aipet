import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireActiveStudent } from '@/lib/subscription';
import { checkRateLimit, sanitizeText } from '@/lib/security';
import { continueConversation, type TutorMessage } from '@/lib/tutor';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  message: z.string().min(1).max(4000),
  locale: z.enum(['en', 'ar']).default('en'),
});

async function postHandler(req: NextRequest, { params }: { params: { id: string } }) {
  const student = await requireActiveStudent();
  if (!student) return NextResponse.json({ error: 'Please log in or subscribe to continue.' }, { status: 401 });

  const limited = await checkRateLimit(req, 'form');
  if (limited) return limited;

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.' }, { status: 400 });
  }
  const { message, locale } = parsed.data;

  const submission = await prisma.submission.findUnique({
    where: { id: params.id },
    include: { exercise: true, tutorSession: true },
  });
  if (!submission || submission.studentId !== student.id || !submission.tutorSession) {
    return NextResponse.json({ error: 'Submission not found.' }, { status: 404 });
  }

  const history = submission.tutorSession.messages as unknown as TutorMessage[];
  const studentMsg: TutorMessage = { role: 'student', content: sanitizeText(message), at: new Date().toISOString() };
  const updatedHistory = [...history, studentMsg];

  let tutorReply: string;
  try {
    tutorReply = await continueConversation(
      {
        statement: locale === 'ar' ? submission.exercise.statementAr : submission.exercise.statementEn,
        officialSolution: locale === 'ar' ? submission.exercise.officialSolutionAr : submission.exercise.officialSolutionEn,
        solutionSteps: locale === 'ar' ? submission.exercise.solutionStepsAr : submission.exercise.solutionStepsEn,
        keyConcepts: locale === 'ar' ? submission.exercise.keyConceptsAr : submission.exercise.keyConceptsEn,
        commonMistakes: locale === 'ar' ? submission.exercise.commonMistakesAr : submission.exercise.commonMistakesEn,
      },
      updatedHistory,
      locale
    );
  } catch (err) {
    console.error('AIPeT continuation failed:', err);
    return NextResponse.json({ error: 'AIPeT could not respond right now. Please try again shortly.' }, { status: 502 });
  }

  const tutorMsg: TutorMessage = { role: 'tutor', content: tutorReply, at: new Date().toISOString() };
  const finalMessages = [...updatedHistory, tutorMsg];

  await prisma.tutorSession.update({
    where: { id: submission.tutorSession.id },
    data: { messages: finalMessages as unknown as object[], attempts: { increment: 1 } },
  });

  return NextResponse.json({ messages: finalMessages });
}

export const POST = withApiHandler(postHandler);
