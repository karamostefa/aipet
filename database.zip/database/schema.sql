-- ============================================================
-- AIPeT — DATABASE SCHEMA (PostgreSQL)
-- Import with:  psql "$DATABASE_URL" -f database/schema.sql
-- This mirrors prisma/schema.prisma exactly. If you use Prisma
-- (recommended), you don't need to run this file manually —
-- `npm run db:push` or `npm run db:migrate` will create it for you.
-- Kept here because a raw, portable SQL file is handy for manual
-- inspection or importing into a host that doesn't run Prisma.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto"; -- for gen_random_uuid()

-- ---------- Enums ----------
CREATE TYPE "AdminRole" AS ENUM ('SUPER_ADMIN', 'CONTENT_ADMIN', 'SUPPORT');
CREATE TYPE "CatalogStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');
CREATE TYPE "AipetStatus" AS ENUM ('PENDING_ACTIVATION', 'ACTIVE', 'SUSPENDED');
CREATE TYPE "ExerciseDifficulty" AS ENUM ('EASY', 'MEDIUM', 'HARD');
CREATE TYPE "SubmissionStatus" AS ENUM ('PROCESSING_OCR', 'IN_PROGRESS', 'RESOLVED', 'FAILED');
CREATE TYPE "SubscriptionPlan" AS ENUM ('MONTHLY', 'TRIMESTER', 'ANNUAL');
CREATE TYPE "SubscriptionStatus" AS ENUM ('TRIALING', 'ACTIVE', 'EXPIRED', 'CANCELLED');
CREATE TYPE "PaymentStatus" AS ENUM ('PENDING', 'PAID', 'FAILED');

-- ---------- Admin (AIPeT's own small content-admin console) ----------
CREATE TABLE "Admin" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "fullName" TEXT NOT NULL,
  role "AdminRole" NOT NULL DEFAULT 'SUPER_ADMIN',
  "isActive" BOOLEAN NOT NULL DEFAULT TRUE,
  "lastLoginAt" TIMESTAMPTZ,
  "failedLoginAttempts" INTEGER NOT NULL DEFAULT 0,
  "lockedUntil" TIMESTAMPTZ,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------- AIPeT subscribers (students) ----------
CREATE TABLE "AipetSubscriber" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "fullName" TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  "passwordHash" TEXT,
  level TEXT,
  stream TEXT,
  "activationToken" TEXT UNIQUE NOT NULL,
  "activationExpiry" TIMESTAMPTZ NOT NULL,
  status "AipetStatus" NOT NULL DEFAULT 'PENDING_ACTIVATION',
  "activatedAt" TIMESTAMPTZ,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "failedLoginAttempts" INTEGER NOT NULL DEFAULT 0,
  "lockedUntil" TIMESTAMPTZ,
  -- Subscription / billing (see src/lib/subscription.ts)
  "trialEndsAt" TIMESTAMPTZ,
  "subscriptionStatus" "SubscriptionStatus" NOT NULL DEFAULT 'TRIALING',
  "subscriptionPlan" "SubscriptionPlan",
  "subscriptionExpiresAt" TIMESTAMPTZ
);

-- ---------- Payments (Chargily Pay) ----------
CREATE TABLE "AipetPayment" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "studentId" UUID NOT NULL REFERENCES "AipetSubscriber"(id),
  plan "SubscriptionPlan" NOT NULL,
  "amountDzd" NUMERIC(10,2) NOT NULL,
  status "PaymentStatus" NOT NULL DEFAULT 'PENDING',
  "providerRef" TEXT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "paidAt" TIMESTAMPTZ
);

-- ---------- AIPeT content model: modules -> units -> exercises ----------
CREATE TABLE "AipetModule" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  "nameEn" TEXT NOT NULL,
  "nameAr" TEXT NOT NULL,
  "descriptionEn" TEXT,
  "descriptionAr" TEXT,
  "order" INTEGER NOT NULL DEFAULT 0,
  status "CatalogStatus" NOT NULL DEFAULT 'DRAFT',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "AipetUnit" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "moduleId" UUID NOT NULL REFERENCES "AipetModule"(id) ON DELETE CASCADE,
  "titleEn" TEXT NOT NULL,
  "titleAr" TEXT NOT NULL,
  "descriptionEn" TEXT,
  "descriptionAr" TEXT,
  "order" INTEGER NOT NULL DEFAULT 0,
  status "CatalogStatus" NOT NULL DEFAULT 'DRAFT',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "AipetExercise" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "unitId" UUID NOT NULL REFERENCES "AipetUnit"(id) ON DELETE CASCADE,
  number INTEGER NOT NULL DEFAULT 1,
  difficulty "ExerciseDifficulty" NOT NULL DEFAULT 'MEDIUM',
  "statementEn" TEXT NOT NULL,
  "statementAr" TEXT NOT NULL,
  "officialSolutionEn" TEXT NOT NULL,
  "officialSolutionAr" TEXT NOT NULL,
  "solutionStepsEn" TEXT NOT NULL,
  "solutionStepsAr" TEXT NOT NULL,
  "keyConceptsEn" TEXT,
  "keyConceptsAr" TEXT,
  "commonMistakesEn" TEXT,
  "commonMistakesAr" TEXT,
  status "CatalogStatus" NOT NULL DEFAULT 'DRAFT',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "Submission" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "studentId" UUID NOT NULL REFERENCES "AipetSubscriber"(id),
  "exerciseId" UUID NOT NULL REFERENCES "AipetExercise"(id),
  "imageUrl" TEXT NOT NULL,
  "ocrText" TEXT,
  status "SubmissionStatus" NOT NULL DEFAULT 'PROCESSING_OCR',
  score INTEGER,
  "reasoningQuality" INTEGER,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "TutorSession" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "submissionId" UUID UNIQUE NOT NULL REFERENCES "Submission"(id) ON DELETE CASCADE,
  "studentId" UUID NOT NULL REFERENCES "AipetSubscriber"(id),
  messages JSONB NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 1,
  "startedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE "Progress" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "studentId" UUID NOT NULL REFERENCES "AipetSubscriber"(id),
  "unitId" UUID NOT NULL REFERENCES "AipetUnit"(id),
  "exercisesAttempted" INTEGER NOT NULL DEFAULT 0,
  "exercisesMastered" INTEGER NOT NULL DEFAULT 0,
  "averageScore" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "reasoningImprovement" DOUBLE PRECISION NOT NULL DEFAULT 0,
  "streakDays" INTEGER NOT NULL DEFAULT 0,
  "lastActivityAt" TIMESTAMPTZ,
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE ("studentId", "unitId")
);

-- One row per plan, editable from /admin/aipet/pricing. Seeded with the
-- blueprint's launch pricing — see database/seed.sql (or prisma/seed.ts).
CREATE TABLE "AipetPricing" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan "SubscriptionPlan" UNIQUE NOT NULL,
  "priceDzd" NUMERIC(10,2) NOT NULL,
  "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- ---------- Helpful indexes ----------
CREATE INDEX idx_unit_module ON "AipetUnit"("moduleId");
CREATE INDEX idx_exercise_unit ON "AipetExercise"("unitId");
CREATE INDEX idx_submission_student ON "Submission"("studentId");
CREATE INDEX idx_submission_exercise ON "Submission"("exerciseId");
CREATE INDEX idx_tutorsession_student ON "TutorSession"("studentId");
CREATE INDEX idx_progress_student ON "Progress"("studentId");
CREATE INDEX idx_progress_unit ON "Progress"("unitId");
CREATE INDEX idx_payment_student ON "AipetPayment"("studentId");
CREATE INDEX idx_payment_status ON "AipetPayment"(status);
