-- ============================================================
-- AIPeT — SAMPLE SEED DATA
-- Import with:  psql "$DATABASE_URL" -f database/seed.sql
-- (run schema.sql first). If you use Prisma (recommended), `npm run
-- db:seed` does the same thing, using prisma/data/aipetContent.json —
-- which has MORE sample content (2 units, 5 exercises total) than the
-- 1-unit/2-exercise subset kept here in plain SQL for quick reference.
-- Prefer `npm run db:seed`; use this file only if you're not using Prisma.
-- ============================================================

-- Sample AIPeT module/unit/exercises — a working example so you can see
-- the exact shape of content to add more of via /admin/aipet.
INSERT INTO "AipetModule" (id, slug, "nameEn", "nameAr", "descriptionEn", "descriptionAr", "order", status)
VALUES ('00000000-0000-0000-0000-000000000001', 'mathematics', 'Mathematics', 'الرياضيات', 'Baccalauréat-level mathematics exercises.', 'تمارين رياضيات لمستوى البكالوريا.', 1, 'PUBLISHED');

INSERT INTO "AipetUnit" (id, "moduleId", "titleEn", "titleAr", "descriptionEn", "descriptionAr", "order", status)
VALUES ('00000000-0000-0000-0000-000000000011', '00000000-0000-0000-0000-000000000001', 'Sequences', 'المتتاليات', 'Arithmetic and geometric sequences, limits, and convergence.', 'المتتاليات الحسابية والهندسية، النهايات، والتقارب.', 1, 'PUBLISHED');

INSERT INTO "AipetExercise" (id, "unitId", number, difficulty, "statementEn", "statementAr", "officialSolutionEn", "officialSolutionAr", "solutionStepsEn", "solutionStepsAr", "keyConceptsEn", "keyConceptsAr", "commonMistakesEn", "commonMistakesAr", status)
VALUES (
  '00000000-0000-0000-0000-000000000111',
  '00000000-0000-0000-0000-000000000011',
  1, 'EASY',
  'Let (u_n) be defined by u_0 = 3 and u_(n+1) = u_n + 5 for all n >= 0. Express u_n in terms of n, then compute u_10.',
  'لتكن (u_n) متتالية معرفة بـ u_0 = 3 و u_(n+1) = u_n + 5 لكل n >= 0. عبر عن u_n بدلالة n، ثم احسب u_10.',
  'This is an arithmetic sequence with first term u_0 = 3 and common difference r = 5. General term: u_n = u_0 + n*r = 3 + 5n. So u_10 = 3 + 50 = 53.',
  'هذه متتالية حسابية حدها الأول u_0 = 3 وأساسها r = 5. الحد العام: u_n = u_0 + n*r = 3 + 5n. إذن u_10 = 3 + 50 = 53.',
  '1) Recognize the recurrence u_(n+1) = u_n + r as arithmetic. 2) Identify u_0 and r from the statement. 3) Apply the formula u_n = u_0 + n*r. 4) Substitute n=10 and compute.',
  '1) التعرف على أن العلاقة u_(n+1) = u_n + r تدل على متتالية حسابية. 2) تحديد u_0 و r من نص التمرين. 3) تطبيق الصيغة u_n = u_0 + n*r. 4) التعويض بـ n=10 والحساب.',
  'Arithmetic sequences, general term formula, recurrence relations.',
  'المتتاليات الحسابية، صيغة الحد العام، علاقات التراجع.',
  'Confusing arithmetic (add r) with geometric (multiply by q) sequences. Off-by-one errors in the general term (using n+1 terms instead of n). Forgetting that u_0 is the first term, not u_1.',
  'الخلط بين المتتالية الحسابية (الجمع) والهندسية (الضرب). أخطاء في عدد الحدود (استعمال n+1 بدل n). نسيان أن u_0 هو الحد الأول وليس u_1.',
  'PUBLISHED'
),
(
  '00000000-0000-0000-0000-000000000112',
  '00000000-0000-0000-0000-000000000011',
  2, 'MEDIUM',
  'Let (v_n) be defined by v_0 = 2 and v_(n+1) = 3*v_n for all n >= 0. Show that (v_n) is geometric, express v_n in terms of n, and compute the sum S = v_0 + v_1 + ... + v_5.',
  'لتكن (v_n) متتالية معرفة بـ v_0 = 2 و v_(n+1) = 3*v_n لكل n >= 0. بين أن (v_n) هندسية، عبر عن v_n بدلالة n، واحسب المجموع S = v_0 + v_1 + ... + v_5.',
  'v_(n+1)/v_n = 3 for all n, so (v_n) is geometric with ratio q=3 and first term v_0=2. General term: v_n = v_0 * q^n = 2*3^n. Sum of first 6 terms (n=0..5): S = v_0*(q^6 - 1)/(q-1) = 2*(729-1)/2 = 728.',
  'v_(n+1)/v_n = 3 لكل n، إذن (v_n) هندسية أساسها q=3 وحدها الأول v_0=2. الحد العام: v_n = v_0 * q^n = 2*3^n. مجموع الحدود الستة الأولى (n=0..5): S = v_0*(q^6 - 1)/(q-1) = 2*(729-1)/2 = 728.',
  '1) Compute the ratio v_(n+1)/v_n and show it is constant to prove geometric. 2) State q and v_0 clearly. 3) Apply v_n = v_0 * q^n. 4) Apply the geometric sum formula for n=0 to 5 (6 terms), being careful with the exponent (q^6, not q^5).',
  '1) حساب النسبة v_(n+1)/v_n وإظهار أنها ثابتة لإثبات أنها هندسية. 2) تحديد q و v_0 بوضوح. 3) تطبيق v_n = v_0 * q^n. 4) تطبيق صيغة مجموع المتتالية الهندسية من n=0 إلى 5 (6 حدود)، مع الانتباه للأس (q^6 وليس q^5).',
  'Geometric sequences, ratio test, geometric series sum formula.',
  'المتتاليات الهندسية، اختبار النسبة، صيغة مجموع المتتالية الهندسية.',
  'Using q^5 instead of q^6 when summing 6 terms (n=0 to 5 inclusive). Forgetting to prove the ratio is constant before calling it geometric. Sign errors when q would be negative (not the case here, but a frequent general mistake).',
  'استعمال q^5 بدل q^6 عند جمع 6 حدود (من n=0 إلى 5 شاملة). نسيان إثبات أن النسبة ثابتة قبل تسمية المتتالية هندسية. أخطاء الإشارة عندما تكون q سالبة (ليست الحالة هنا، لكنه خطأ شائع بشكل عام).',
  'PUBLISHED'
);

-- Default subscription prices — editable later from /admin/aipet/pricing,
-- this only sets the starting values so checkout works before an admin
-- ever visits that page.
INSERT INTO "AipetPricing" (plan, "priceDzd") VALUES
  ('MONTHLY', 800),
  ('TRIMESTER', 2100),
  ('ANNUAL', 7500);

-- NOTE: the "Admin" table needs a bcrypt password hash, not a plain
-- password, so it's not included here as raw SQL. Use `npm run db:seed`
-- (prisma/seed.ts) to create the admin account safely, or hash a
-- password yourself and INSERT INTO "Admin" manually.
