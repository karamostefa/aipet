# AIPeT — 6-Day Build & Integration Plan (6 hours/day = 36 hours total)

This assumes you're building AIPeT as its own application (per your
architecture blueprint: Next.js + FastAPI + Supabase + Mathpix + Claude),
separate from the caia.dz marketing/e-commerce site, then connecting the
two. That separation is deliberate — AIPeT has a completely different job
(AI tutoring, OCR, vector search) than caia.dz (content + payments), and
keeping them as two deployable apps means a bug or traffic spike in one
never takes down the other.

Each day is 6 focused hours. Times are guidance, not law — if something
runs long, push the leftover into the next day's first hour rather than
cutting corners on security or the core tutoring logic.

---

## Day 1 — Foundations: data model + auth (6h)

**Goal: a student can sign up, log in, and see an empty dashboard.**

- (1h) Set up the two repos/projects: `aipet-frontend` (Next.js 14 +
  TypeScript + Tailwind) and `aipet-backend` (FastAPI + Python 3.11).
  Connect both to a Supabase Postgres project (can be the *same* Supabase
  project as caia.dz, in a separate schema, or a fully separate project —
  separate project is simpler to reason about for billing/limits).
- (2h) Implement the database schema from your blueprint: `users`,
  `subjects`, `units`, `exercises`, `submissions`, `progress`,
  `tutor_sessions`. Add one more table this plan needs:
  `activation_tokens` (or reuse the `AipetSubscriber` table already built
  in caia.dz — see Day 6 for how the two connect).
- (2h) Auth: Supabase Auth (email/password) for students. Wire the
  activation-link flow: student registers → confirmation email → clicking
  it marks them verified → redirected to onboarding (choose level/stream).
- (1h) A bare dashboard page showing "0 exercises attempted" placeholders,
  deployed to a temporary URL (Vercel preview) so you can click through
  the real flow end-to-end.

**End of Day 1 check:** you can register a test account, click an
activation email, and land on a dashboard.

## Day 2 — Content model: units and exercises (6h)

**Goal: the exercise bank exists and is browsable.**

- (1h) Build the admin-only content entry format: a simple JSON or Markdown
  structure per exercise (statement, official solution, solution steps,
  key concepts, common mistakes) — this is what your tutor prompt will
  reference later, so get the shape right now.
- (3h) Enter or import your first real unit (start with one — e.g.
  "Sequences," Bac Math stream) with ~15-20 exercises, fully filled in
  (statement + official solution + step breakdown + common-mistake notes).
  This is the most time-consuming and most important part of the whole
  project: **the tutor is only as good as this content.**
- (1h) Build the "choose a unit → see exercise list" browsing pages on
  the frontend.
- (1h) Build the "exercise detail" page: shows the statement, an upload
  button (photo of handwritten work), placeholder for AIPeT's response.

**End of Day 2 check:** a student can browse to a real exercise and see
its statement, with an (unfunctional yet) upload button.

## Day 3 — OCR pipeline: photo → readable math (6h)

**Goal: a photographed handwritten solution becomes structured text/LaTeX.**

- (1h) Get a Mathpix API key (or OpenAI Vision / Google Vision as a
  fallback if Mathpix's pricing doesn't fit) and test it standalone with a
  few sample photos of handwriting.
- (2h) Backend endpoint: accepts an uploaded image, stores it (Supabase
  Storage), calls Mathpix, stores the returned LaTeX/text on the
  `submissions` row.
- (2h) Frontend: camera/file upload component (mobile-first — most
  Algerian students will use a phone camera), upload progress, and a
  "here's what we read from your photo, does this look right?" confirmation
  step (letting the student fix obvious OCR mistakes before AIPeT reasons
  over broken text is worth the extra UI).
- (1h) Handle failure cases gracefully: blurry photo, no text detected,
  OCR confidence too low — clear retry messaging rather than a silent
  wrong analysis.

**End of Day 3 check:** uploading a real handwritten photo produces
readable text/LaTeX you can see stored in the database.

## Day 4 — The tutor itself: reasoning analysis (6h)

**Goal: AIPeT actually critiques the student's reasoning — the core feature.**

- (1h) Finalize the system prompt (you already have a strong draft in your
  blueprint) — the non-negotiables: never give the final answer, always
  locate the *exact step* where reasoning diverged, always ask a guiding
  question rather than stating the fix outright.
- (2h) Backend endpoint: given (exercise's official solution + step
  breakdown + common mistakes) and (student's OCR'd submission), call the
  Claude API with that system prompt plus both pieces of content. Parse
  the response into: {diagnosis, first-deviation-point, guiding question}.
- (2h) Frontend: render AIPeT's response as a conversation (not a wall of
  text) — the student can reply, ask "why," or upload a corrected attempt,
  and the loop continues (`tutor_sessions.messages` stores this thread).
- (1h) Test with 5-10 real (or realistic fake) handwritten submissions,
  including deliberately wrong ones, and read the responses critically —
  is it actually teaching, or accidentally leaking the answer? Tighten the
  prompt based on what you see.

**End of Day 4 check:** you can upload a wrong solution and get back a
genuinely Socratic response that doesn't give away the answer.

## Day 5 — Progress dashboard + subscription gating (6h)

**Goal: the "improves itself over time" and "monthly subscription" pieces.**

- (2h) Progress tracking: after each submission, update `progress`
  (exercises_attempted, exercises_mastered, average_score,
  reasoning_improvement, streak_days). Build the dashboard UI: per-unit
  progress bars, a simple trend chart (reasoning quality over time), streaks.
- (2h) Subscription gating: reuse the same Chargily/Stripe pattern already
  built for caia.dz (see `src/lib/payments/` in the caia.dz codebase — copy
  those two files as a starting point) for the monthly/trimester/annual
  plans from your blueprint. Free 7-day trial: just check
  `subscriptions.started_at` vs. now, no payment required until day 7.
- (1h) "Self-strengthening" loop, v1 (keep this simple for launch — you can
  make it more sophisticated later): log every (exercise, common mistake
  triggered, student outcome) triple. Once a week, review which common
  mistakes are hit most often per exercise and refine that exercise's
  "common_mistakes" field — this is a manual-but-informed process at first,
  not a fully automated retraining loop (that's a fine v2 goal, not a
  6-day one).
- (1h) PWA setup (`next-pwa`): manifest, icons, offline caching for already-
  loaded exercises, "Add to Home Screen" prompt — important for your
  Android-first user base.

**End of Day 5 check:** the dashboard shows real progress data, and a
non-subscribed user is correctly blocked after their trial with a clear
upgrade prompt.

## Day 6 — Polish + integration with caia.dz (6h)

**Goal: a visitor on caia.dz can smoothly become an AIPeT student.**

- (1h) Cross-app handoff: today, caia.dz's `/aipet` page collects
  name/email/phone and sends an activation email
  (`/api/aipet/activate/[token]`) that currently just flips a status flag
  and redirects back to the marketing page. Change that redirect target to
  the real AIPeT app's onboarding URL, e.g.
  `https://app.caia.dz/onboarding?email=...&verified=1` — sign that URL
  with a short-lived token (reuse the JWT helper already in
  `src/lib/auth.ts`) so AIPeT can trust "this email was really verified by
  caia.dz" without asking the student to verify twice.
- (1h) Decide the subdomain structure: `caia.dz` (marketing/e-commerce,
  already built) and `app.caia.dz` (AIPeT itself). Both can be separate
  Vercel projects pointed at the same registrar's DNS once you own the
  domain — just two CNAME/A records instead of one.
- (2h) Visual consistency pass: import the same Tailwind design tokens
  (colors, fonts) from the caia.dz project into AIPeT so it doesn't feel
  like a different product — students should recognize the brand.
- (1h) End-to-end test of the full journey: visit caia.dz → click AIPeT →
  sign up → activate → land in app.caia.dz → upload a real exercise photo
  → get a real tutoring response → see it reflected on the dashboard.
- (1h) Write down (even briefly) your weekly content-review habit from
  Day 5, and schedule your first real week of usage with a small group of
  test students before a public launch — their confusion points will tell
  you more in a day than another week of solo testing would.

**End of Day 6 check:** the full loop — marketing site → signup →
activation → tutoring → progress tracking — works for a real student,
end to end.

---

## After Day 6 — what's intentionally deferred

- Automated retraining/fine-tuning of the tutor's behavior from aggregate
  student data (the blueprint's "improves itself" framing) — start with
  the manual weekly content review above; a fully automated feedback loop
  is a multi-week project of its own once you have real usage data to
  learn from.
- More subjects/streams beyond your first unit — repeat Day 2's content
  process per unit; it's genuinely the long pole, not a one-time task.
- SMS-based (not just email) activation, once you've picked an
  Algeria-capable SMS provider (noted in the caia.dz README too).
