// Run with: npm run db:seed
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { readFileSync } from 'fs';
import { join } from 'path';

const prisma = new PrismaClient();

async function main() {
  // --- Admin account ---
  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@aipet.dz';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe!2026';
  const passwordHash = await bcrypt.hash(adminPassword, 10);
  await prisma.admin.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      passwordHash,
      fullName: 'AIPeT Admin',
      role: 'SUPER_ADMIN',
    },
  });
  console.log(`Admin created. Email: ${adminEmail}  Password: ${adminPassword}`);
  console.log('>>> CHANGE THIS PASSWORD IMMEDIATELY AFTER YOUR FIRST LOGIN <<<');

  // --- Default subscription prices (editable later from /admin/aipet/pricing) ---
  const defaultPrices: Record<'MONTHLY' | 'TRIMESTER' | 'ANNUAL', number> = {
    MONTHLY: 800,
    TRIMESTER: 2100,
    ANNUAL: 7500,
  };
  for (const [plan, priceDzd] of Object.entries(defaultPrices)) {
    await prisma.aipetPricing.upsert({
      where: { plan: plan as any },
      update: {},
      create: { plan: plan as any, priceDzd },
    });
  }
  console.log('Seeded default pricing:', defaultPrices);

  // --- AIPeT sample content: 1 module, multiple units, multiple exercises each ---
  const aipetPath = join(__dirname, 'data', 'aipetContent.json');
  const aipetData = JSON.parse(readFileSync(aipetPath, 'utf-8'));

  const module_ = await prisma.aipetModule.upsert({
    where: { slug: aipetData.module.slug },
    update: aipetData.module,
    create: aipetData.module,
  });

  let totalExercises = 0;
  for (const unitData of aipetData.units) {
    const { exercises, ...unitFields } = unitData;

    const existingUnit = await prisma.aipetUnit.findFirst({
      where: { moduleId: module_.id, titleEn: unitFields.titleEn },
    });
    const unit = existingUnit
      ? await prisma.aipetUnit.update({ where: { id: existingUnit.id }, data: unitFields })
      : await prisma.aipetUnit.create({ data: { ...unitFields, moduleId: module_.id } });

    for (const ex of exercises) {
      const existingExercise = await prisma.aipetExercise.findFirst({
        where: { unitId: unit.id, number: ex.number },
      });
      if (existingExercise) {
        await prisma.aipetExercise.update({ where: { id: existingExercise.id }, data: ex });
      } else {
        await prisma.aipetExercise.create({ data: { ...ex, unitId: unit.id } });
      }
      totalExercises++;
    }
  }
  console.log(`Seeded AIPeT sample content: 1 module, ${aipetData.units.length} units, ${totalExercises} exercises.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
