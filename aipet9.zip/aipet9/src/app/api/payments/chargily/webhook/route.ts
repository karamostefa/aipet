import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { verifyChargilySignature } from '@/lib/payments/chargily';
import { sendMail } from '@/lib/mail';
import { PLAN_DURATION_DAYS, PLAN_LABELS, isValidPlan } from '@/lib/subscription';
import { withApiHandler } from '@/lib/apiHandler';

// Chargily calls this endpoint server-to-server when a payment's status
// changes. We NEVER trust the success/failure redirect URLs to grant
// access — only a verified webhook can do that, because redirect URLs
// are visited by the customer's browser and can be replayed or guessed.
async function postHandler(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('signature');

  if (!verifyChargilySignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Invalid signature.' }, { status: 401 });
  }

  let payload: any;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }
  const status = payload.status as string;
  const metadata = (payload.metadata || {}) as Record<string, string>;

  if (status !== 'paid') {
    return NextResponse.json({ status: 'ignored' });
  }

  if (metadata.kind !== 'aipet_subscription' || !metadata.paymentId || !metadata.studentId || !isValidPlan(metadata.plan)) {
    return NextResponse.json({ status: 'ignored' });
  }

  const payment = await prisma.aipetPayment.findUnique({ where: { id: metadata.paymentId } });
  if (!payment || payment.status === 'PAID') {
    // Already processed (Chargily may retry webhooks) — respond 200 so it stops retrying.
    return NextResponse.json({ status: 'ok' });
  }

  const plan = metadata.plan;
  const durationMs = PLAN_DURATION_DAYS[plan] * 24 * 60 * 60 * 1000;

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: metadata.studentId } });
  if (!student) {
    return NextResponse.json({ status: 'ignored' });
  }

  // Renewals stack on top of remaining time rather than resetting the
  // clock, so paying early never costs a student days they already paid for.
  const now = new Date();
  const currentExpiry =
    student.subscriptionStatus === 'ACTIVE' && student.subscriptionExpiresAt && student.subscriptionExpiresAt > now
      ? student.subscriptionExpiresAt
      : now;
  const newExpiry = new Date(currentExpiry.getTime() + durationMs);

  await prisma.$transaction([
    prisma.aipetPayment.update({
      where: { id: payment.id },
      data: { status: 'PAID', paidAt: now, providerRef: payload.id },
    }),
    prisma.aipetSubscriber.update({
      where: { id: student.id },
      data: { subscriptionStatus: 'ACTIVE', subscriptionPlan: plan, subscriptionExpiresAt: newExpiry },
    }),
  ]);

  await sendMail(
    student.email,
    'AIPeT — subscription confirmed',
    `<div style="font-family: Arial, sans-serif; max-width: 480px; margin: auto;">
      <h2 style="color:#161D3E;">Thanks, ${student.fullName}!</h2>
      <p>Your ${PLAN_LABELS[plan].en} AIPeT subscription is active until ${newExpiry.toDateString()}.</p>
    </div>`
  ).catch((e) => console.error('Subscription confirmation email failed:', e));

  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
