import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireStudent } from '@/lib/studentAuth';
import { checkRateLimit } from '@/lib/security';
import { createChargilyCheckout } from '@/lib/payments/chargily';
import { getPlanPrices, PLAN_LABELS, isValidPlan } from '@/lib/subscription';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  plan: z.enum(['MONTHLY', 'TRIMESTER', 'ANNUAL']),
  locale: z.enum(['en', 'ar']).default('en'),
});

async function postHandler(req: NextRequest) {
  const student = await requireStudent();
  if (!student) return NextResponse.json({ error: 'Please log in.' }, { status: 401 });

  const limited = await checkRateLimit(req, 'form');
  if (limited) return limited;

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success || !isValidPlan(parsed.data.plan)) {
    return NextResponse.json({ error: 'Invalid plan.' }, { status: 400 });
  }
  const { plan, locale } = parsed.data;

  // Always the live, admin-editable price — never a value the client sent.
  const prices = await getPlanPrices();
  const amountDzd = prices[plan];
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

  const payment = await prisma.aipetPayment.create({
    data: {
      studentId: student.studentId,
      plan,
      amountDzd,
      status: 'PENDING',
    },
  });

  try {
    const checkout = await createChargilyCheckout({
      amountDzd,
      description: `AIPeT — ${PLAN_LABELS[plan].en} subscription`,
      successUrl: `${siteUrl}/${locale}/aipet/subscribe/success`,
      failureUrl: `${siteUrl}/${locale}/aipet/subscribe/failed`,
      webhookUrl: `${siteUrl}/api/payments/chargily/webhook`,
      customerEmail: student.email,
      metadata: { kind: 'aipet_subscription', paymentId: payment.id, studentId: student.studentId, plan },
    });

    await prisma.aipetPayment.update({ where: { id: payment.id }, data: { providerRef: checkout.id } });
    return NextResponse.json({ checkoutUrl: checkout.checkout_url });
  } catch (err) {
    console.error('Chargily checkout creation failed:', err);
    await prisma.aipetPayment.update({ where: { id: payment.id }, data: { status: 'FAILED' } });
    return NextResponse.json(
      { error: 'Could not start payment right now (Chargily may not be configured yet). Please try again shortly.' },
      { status: 502 }
    );
  }
}

export const POST = withApiHandler(postHandler);
