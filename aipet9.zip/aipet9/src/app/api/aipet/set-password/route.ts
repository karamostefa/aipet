import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { checkRateLimit } from '@/lib/security';
import { hashPassword, signStudentSession, setStudentSessionCookie, requestIsHttps } from '@/lib/studentAuth';
import { TRIAL_DAYS } from '@/lib/subscription';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  token: z.string().min(10),
  password: z.string().min(8).max(200),
});

async function postHandler(req: NextRequest) {
  const limited = await checkRateLimit(req, 'form');
  if (limited) return limited;

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Please choose a password with at least 8 characters.' }, { status: 400 });
  }
  const { token, password } = parsed.data;

  const subscriber = await prisma.aipetSubscriber.findUnique({ where: { activationToken: token } });
  if (!subscriber) {
    return NextResponse.json({ error: 'Invalid or already-used activation link.' }, { status: 404 });
  }
  if (subscriber.activationExpiry < new Date()) {
    return NextResponse.json({ error: 'This activation link has expired. Please sign up again.' }, { status: 410 });
  }

  const passwordHash = await hashPassword(password);
  const now = new Date();
  // The 7-day free trial starts here, at activation — not at signup —
  // so a student who signs up but takes a few days to click the
  // activation email doesn't lose trial time waiting.
  const trialEndsAt = new Date(now.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
  const updated = await prisma.aipetSubscriber.update({
    where: { id: subscriber.id },
    data: {
      passwordHash,
      status: 'ACTIVE',
      activatedAt: now,
      trialEndsAt,
      subscriptionStatus: 'TRIALING',
    },
  });

  const session = await signStudentSession({ studentId: updated.id, email: updated.email, fullName: updated.fullName });
  setStudentSessionCookie(session, requestIsHttps(req));

  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
