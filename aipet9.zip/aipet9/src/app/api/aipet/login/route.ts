import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { checkRateLimit } from '@/lib/security';
import { verifyPassword, signStudentSession, setStudentSessionCookie, requestIsHttps } from '@/lib/studentAuth';
import { withApiHandler } from '@/lib/apiHandler';
import { isLockedOut, nextFailureState, resetFailureState, lockedOutMessage } from '@/lib/accountLockout';
import { z } from 'zod';

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(200),
});

async function postHandler(req: NextRequest) {
  const limited = await checkRateLimit(req, 'login');
  if (limited) return limited;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid email or password.' }, { status: 400 });
  }
  const { email, password } = parsed.data;

  const genericError = NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
  const student = await prisma.aipetSubscriber.findUnique({ where: { email } });
  if (!student || !student.passwordHash || student.status !== 'ACTIVE') return genericError;

  if (isLockedOut(student)) {
    return NextResponse.json({ error: lockedOutMessage() }, { status: 429 });
  }

  const valid = await verifyPassword(password, student.passwordHash);
  if (!valid) {
    await prisma.aipetSubscriber.update({ where: { id: student.id }, data: nextFailureState(student) });
    return genericError;
  }

  await prisma.aipetSubscriber.update({ where: { id: student.id }, data: resetFailureState });
  const session = await signStudentSession({ studentId: student.id, email: student.email, fullName: student.fullName });
  setStudentSessionCookie(session, requestIsHttps(req));

  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
