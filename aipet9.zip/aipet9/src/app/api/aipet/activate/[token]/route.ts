import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { withApiHandler } from '@/lib/apiHandler';

// Clicking the activation link doesn't activate the account outright —
// it lands the student on a "set your password" page (still using the
// same token, checked again there) so they leave the flow with real
// credentials to log back in with later.
async function getHandler(req: NextRequest, { params }: { params: { token: string } }) {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const subscriber = await prisma.aipetSubscriber.findUnique({ where: { activationToken: params.token } });

  if (!subscriber) {
    return NextResponse.redirect(`${siteUrl}/en/aipet?activation=invalid`);
  }
  if (subscriber.activationExpiry < new Date()) {
    return NextResponse.redirect(`${siteUrl}/en/aipet?activation=expired`);
  }

  return NextResponse.redirect(`${siteUrl}/en/aipet/set-password?token=${params.token}`);
}

export const GET = withApiHandler(getHandler);
