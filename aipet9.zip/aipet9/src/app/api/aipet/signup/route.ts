import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { prisma } from '@/lib/db';
import { aipetSignupSchema, checkRateLimit, sanitizeText } from '@/lib/security';
import { sendMail, activationEmailHtml } from '@/lib/mail';
import { withApiHandler } from '@/lib/apiHandler';

async function postHandler(req: NextRequest) {
  const limited = await checkRateLimit(req, 'form');
  if (limited) return limited;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }
  const parsed = aipetSignupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const { fullName, email, phone } = parsed.data;

  const existing = await prisma.aipetSubscriber.findUnique({ where: { email } });
  if (existing && existing.status === 'ACTIVE') {
    return NextResponse.json({ error: 'This email is already registered and active.' }, { status: 409 });
  }

  const activationToken = crypto.randomBytes(32).toString('hex');
  const activationExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h

  // This write is the entire point of this endpoint — if it throws (bad
  // DATABASE_URL, DB unreachable, etc.) withApiHandler below catches it,
  // logs it server-side, and still returns clean JSON to the browser.
  // Previously this wasn't wrapped in try/catch anywhere up the call
  // stack, so a DB error here silently broke the whole request with no
  // subscriber row created and no error the user could actually read.
  const subscriber = await prisma.aipetSubscriber.upsert({
    where: { email },
    update: {
      fullName: sanitizeText(fullName),
      phone: sanitizeText(phone),
      activationToken,
      activationExpiry,
      status: 'PENDING_ACTIVATION',
    },
    create: {
      fullName: sanitizeText(fullName),
      email,
      phone: sanitizeText(phone),
      activationToken,
      activationExpiry,
    },
  });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const activationUrl = `${siteUrl}/api/aipet/activate/${activationToken}`;

  try {
    await sendMail(email, 'Activate your AIPeT account', activationEmailHtml(fullName, activationUrl));
  } catch (err) {
    console.error('Activation email failed to send:', err);
    // Don't fail the whole request — the record exists (see above) and
    // can be resent from /admin/aipet/students, where the activation
    // link is also shown directly in case SMTP still isn't configured.
  }
  // Always logged, not just on email failure — handy in dev/before SMTP
  // is configured, and as a paper trail either way.
  console.log(`[AIPeT signup] ${email} — activation link: ${activationUrl}`);

  // TODO: send an SMS/OTP code to `subscriber.phone` once an Algeria-capable
  // SMS provider (e.g. an aggregator that supports Mobilis/Djezzy/Ooredoo) is
  // chosen — see the README for notes on this.

  return NextResponse.json({ id: subscriber.id, status: 'PENDING_ACTIVATION' });
}

export const POST = withApiHandler(postHandler);
