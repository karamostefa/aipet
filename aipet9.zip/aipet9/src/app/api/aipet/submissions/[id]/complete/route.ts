import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireActiveStudent } from '@/lib/subscription';
import { withApiHandler } from '@/lib/apiHandler';

// The tutor is deliberately Socratic, not an auto-grader — it never
// declares "correct/incorrect" with a numeric score. Instead, the student
// marks an exercise solved once they feel they've reached the right
// reasoning, which is what actually powers the progress dashboard.
async function postHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  const student = await requireActiveStudent();
  if (!student) return NextResponse.json({ error: 'Please log in or subscribe to continue.' }, { status: 401 });

  const submission = await prisma.submission.findUnique({
    where: { id: params.id },
    include: { exercise: true },
  });
  if (!submission || submission.studentId !== student.id) {
    return NextResponse.json({ error: 'Submission not found.' }, { status: 404 });
  }

  await prisma.submission.update({
    where: { id: submission.id },
    data: { status: 'RESOLVED', score: 100, reasoningQuality: 90 },
  });

  const exercises = await prisma.aipetExercise.findMany({
    where: { unitId: submission.exercise.unitId, status: 'PUBLISHED' },
    select: { id: true },
  });
  const exerciseIds = exercises.map((e) => e.id);
  const submissions = await prisma.submission.findMany({
    where: { studentId: student.id, exerciseId: { in: exerciseIds } },
    select: { exerciseId: true, score: true },
  });
  const attempted = new Set(submissions.map((s) => s.exerciseId));
  const mastered = new Set(submissions.filter((s) => (s.score ?? 0) >= 70).map((s) => s.exerciseId));
  const scores = submissions.filter((s) => s.score != null).map((s) => s.score!) as number[];
  const averageScore = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

  await prisma.progress.upsert({
    where: { studentId_unitId: { studentId: student.id, unitId: submission.exercise.unitId } },
    update: { exercisesAttempted: attempted.size, exercisesMastered: mastered.size, averageScore, lastActivityAt: new Date() },
    create: {
      studentId: student.id,
      unitId: submission.exercise.unitId,
      exercisesAttempted: attempted.size,
      exercisesMastered: mastered.size,
      averageScore,
      lastActivityAt: new Date(),
    },
  });

  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
