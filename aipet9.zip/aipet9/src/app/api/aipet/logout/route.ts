import { NextResponse } from 'next/server';
import { clearStudentSessionCookie } from '@/lib/studentAuth';
import { withApiHandler } from '@/lib/apiHandler';

async function postHandler() {
  clearStudentSessionCookie();
  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
