import { NextResponse } from 'next/server';
import { clearSessionCookie } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';

async function postHandler() {
  clearSessionCookie();
  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
