import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';

async function getHandler() {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const students = await prisma.aipetSubscriber.findMany({
    orderBy: { createdAt: 'desc' },
    take: 500,
    select: {
      id: true,
      fullName: true,
      email: true,
      phone: true,
      status: true,
      activationToken: true,
      activationExpiry: true,
      subscriptionStatus: true,
      trialEndsAt: true,
      subscriptionExpiresAt: true,
      createdAt: true,
    },
  });
  return NextResponse.json(students);
}

export const GET = withApiHandler(getHandler);
