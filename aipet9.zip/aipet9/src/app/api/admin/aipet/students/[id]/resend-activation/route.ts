import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { sendMail, activationEmailHtml } from '@/lib/mail';

async function postHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: params.id } });
  if (!student) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (student.status === 'ACTIVE') {
    return NextResponse.json({ error: 'This student already activated their account.' }, { status: 409 });
  }

  // Refresh the expiry while we're here, in case the original 24h link lapsed.
  const activationExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const updated = await prisma.aipetSubscriber.update({
    where: { id: student.id },
    data: { activationExpiry },
  });

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const activationUrl = `${siteUrl}/api/aipet/activate/${updated.activationToken}`;

  let emailSent = true;
  try {
    await sendMail(updated.email, 'Activate your AIPeT account', activationEmailHtml(updated.fullName, activationUrl));
  } catch (err) {
    console.error('Resend activation email failed:', err);
    emailSent = false;
  }

  return NextResponse.json({ activationUrl, emailSent });
}

export const POST = withApiHandler(postHandler);
