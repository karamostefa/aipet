import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  moduleId: z.string().uuid(),
  titleEn: z.string().min(1).max(200),
  titleAr: z.string().min(1).max(200),
  descriptionEn: z.string().max(2000).optional(),
  descriptionAr: z.string().max(2000).optional(),
  order: z.number().int().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']),
});

async function getHandler() {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const units = await prisma.aipetUnit.findMany({ orderBy: { order: 'asc' }, include: { module: true, exercises: true } });
  return NextResponse.json(units);
}

async function postHandler(req: NextRequest) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const unit = await prisma.aipetUnit.create({ data: parsed.data });
  return NextResponse.json(unit, { status: 201 });
}

export const GET = withApiHandler(getHandler);
export const POST = withApiHandler(postHandler);
