import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  moduleId: z.string().uuid(),
  titleEn: z.string().min(1).max(200),
  titleAr: z.string().min(1).max(200),
  descriptionEn: z.string().max(2000).optional(),
  descriptionAr: z.string().max(2000).optional(),
  order: z.number().int().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']),
});

async function getHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const unit = await prisma.aipetUnit.findUnique({ where: { id: params.id } });
  if (!unit) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json(unit);
}

async function patchHandler(req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const unit = await prisma.aipetUnit.update({ where: { id: params.id }, data: parsed.data });
  return NextResponse.json(unit);
}

async function deleteHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  await prisma.aipetUnit.delete({ where: { id: params.id } }); // cascades to exercises
  return NextResponse.json({ status: 'ok' });
}

export const GET = withApiHandler(getHandler);
export const PATCH = withApiHandler(patchHandler);
export const DELETE = withApiHandler(deleteHandler);
