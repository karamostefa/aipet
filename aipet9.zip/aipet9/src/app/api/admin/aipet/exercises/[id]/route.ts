import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { z } from 'zod';

const schema = z.object({
  unitId: z.string().uuid(),
  number: z.number().int().positive(),
  difficulty: z.enum(['EASY', 'MEDIUM', 'HARD']),
  statementEn: z.string().min(1).max(5000),
  statementAr: z.string().min(1).max(5000),
  officialSolutionEn: z.string().min(1).max(10000),
  officialSolutionAr: z.string().min(1).max(10000),
  solutionStepsEn: z.string().min(1).max(10000),
  solutionStepsAr: z.string().min(1).max(10000),
  keyConceptsEn: z.string().max(3000).optional(),
  keyConceptsAr: z.string().max(3000).optional(),
  commonMistakesEn: z.string().max(3000).optional(),
  commonMistakesAr: z.string().max(3000).optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']),
});

async function getHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const exercise = await prisma.aipetExercise.findUnique({ where: { id: params.id } });
  if (!exercise) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json(exercise);
}

async function patchHandler(req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const exercise = await prisma.aipetExercise.update({ where: { id: params.id }, data: parsed.data });
  return NextResponse.json(exercise);
}

async function deleteHandler(_req: NextRequest, { params }: { params: { id: string } }) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  await prisma.aipetExercise.delete({ where: { id: params.id } });
  return NextResponse.json({ status: 'ok' });
}

export const GET = withApiHandler(getHandler);
export const PATCH = withApiHandler(patchHandler);
export const DELETE = withApiHandler(deleteHandler);
