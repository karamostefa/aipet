import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { getPlanPrices, type Plan } from '@/lib/subscription';
import { z } from 'zod';

const schema = z.object({
  MONTHLY: z.number().positive().max(1_000_000),
  TRIMESTER: z.number().positive().max(1_000_000),
  ANNUAL: z.number().positive().max(1_000_000),
});

async function getHandler() {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const prices = await getPlanPrices();
  return NextResponse.json(prices);
}

async function putHandler(req: NextRequest) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: 'Validation failed.', details: parsed.error.flatten() }, { status: 400 });
  }
  const plans: Plan[] = ['MONTHLY', 'TRIMESTER', 'ANNUAL'];
  await prisma.$transaction(
    plans.map((plan) =>
      prisma.aipetPricing.upsert({
        where: { plan },
        update: { priceDzd: parsed.data[plan] },
        create: { plan, priceDzd: parsed.data[plan] },
      })
    )
  );
  return NextResponse.json(await getPlanPrices());
}

export const GET = withApiHandler(getHandler);
export const PUT = withApiHandler(putHandler);
