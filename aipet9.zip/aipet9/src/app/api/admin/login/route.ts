import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { adminLoginSchema, checkRateLimit } from '@/lib/security';
import { verifyPassword, signSession, setSessionCookie, requestIsHttps } from '@/lib/auth';
import { withApiHandler } from '@/lib/apiHandler';
import { isLockedOut, nextFailureState, resetFailureState, lockedOutMessage } from '@/lib/accountLockout';

async function postHandler(req: NextRequest) {
  // Per-IP rate limiting: 5 attempts/minute/IP on this endpoint.
  const limited = await checkRateLimit(req, 'login');
  if (limited) return limited;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }
  const parsed = adminLoginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid email or password format.' }, { status: 400 });
  }
  const { email, password } = parsed.data;

  const admin = await prisma.admin.findUnique({ where: { email } });
  // Deliberately vague error message — never reveal whether the email
  // exists, which would let an attacker enumerate admin accounts.
  const genericError = NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });

  if (!admin || !admin.isActive) return genericError;

  // Per-ACCOUNT lockout: catches credential stuffing from many IPs,
  // which per-IP rate limiting above can't see.
  if (isLockedOut(admin)) {
    return NextResponse.json({ error: lockedOutMessage() }, { status: 429 });
  }

  const valid = await verifyPassword(password, admin.passwordHash);
  if (!valid) {
    await prisma.admin.update({ where: { id: admin.id }, data: nextFailureState(admin) });
    return genericError;
  }

  const token = await signSession({ adminId: admin.id, email: admin.email, role: admin.role });
  setSessionCookie(token, requestIsHttps(req));
  await prisma.admin.update({ where: { id: admin.id }, data: { lastLoginAt: new Date(), ...resetFailureState } });

  return NextResponse.json({ status: 'ok' });
}

export const POST = withApiHandler(postHandler);
