import './globals.css';
import type { ReactNode } from 'react';

// This root layout is intentionally minimal — real <html>/<body>/fonts/
// direction are set per-locale in src/app/[locale]/layout.tsx, since
// they depend on which language is active.
export default function RootLayout({ children }: { children: ReactNode }) {
  return children;
}
