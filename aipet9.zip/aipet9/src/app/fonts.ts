import { Fraunces, Inter, IBM_Plex_Mono, Noto_Kufi_Arabic, IBM_Plex_Sans_Arabic } from 'next/font/google';

// Latin (English) pairing: Fraunces is a high-contrast serif with real
// editorial/academic character (chosen over a generic sans display to
// match "academy" — research gravitas, not a generic SaaS look).
// Inter carries body copy cleanly at small sizes for long-form syllabi.
export const displayFont = Fraunces({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-display',
});

export const bodyFont = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-body',
});

export const monoFont = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
});

// Arabic pairing: Noto Kufi Arabic for display (geometric, confident,
// reads well at large sizes) + IBM Plex Sans Arabic for body (designed
// as a genuine multi-script companion to IBM Plex Mono/Sans used above).
export const displayFontAr = Noto_Kufi_Arabic({
  subsets: ['arabic'],
  weight: ['600', '700'],
  variable: '--font-display',
});

export const bodyFontAr = IBM_Plex_Sans_Arabic({
  subsets: ['arabic'],
  weight: ['400', '500', '600'],
  variable: '--font-body',
});
