'use client';

import { useEffect, useState } from 'react';

interface Student {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  status: 'PENDING_ACTIVATION' | 'ACTIVE' | 'SUSPENDED';
  activationToken: string;
  activationExpiry: string;
  subscriptionStatus: 'TRIALING' | 'ACTIVE' | 'EXPIRED' | 'CANCELLED';
  trialEndsAt: string | null;
  subscriptionExpiresAt: string | null;
  createdAt: string;
}

function computeAccess(s: Student): { label: string; color: string; until: string | null } {
  const now = new Date();
  if (s.subscriptionStatus === 'ACTIVE' && s.subscriptionExpiresAt && new Date(s.subscriptionExpiresAt) > now) {
    return { label: 'Active', color: 'text-teal-400', until: s.subscriptionExpiresAt };
  }
  if (s.subscriptionStatus === 'TRIALING' && s.trialEndsAt && new Date(s.trialEndsAt) > now) {
    return { label: 'Trialing', color: 'text-gold-500', until: s.trialEndsAt };
  }
  return { label: 'No access', color: 'text-red-400', until: null };
}

export default function AdminAipetStudentsPage() {
  const [students, setStudents] = useState<Student[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  function load() {
    fetch('/api/admin/aipet/students')
      .then((res) => res.json())
      .then(setStudents)
      .catch(() => setError('Could not load students.'));
  }

  useEffect(load, []);

  function activationUrl(token: string) {
    const base = typeof window !== 'undefined' ? window.location.origin : '';
    return `${base}/api/aipet/activate/${token}`;
  }

  async function handleResend(id: string) {
    setBusyId(id);
    setNote(null);
    try {
      const res = await fetch(`/api/admin/aipet/students/${id}/resend-activation`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed.');
      setNote(
        data.emailSent
          ? 'Activation email resent successfully.'
          : `Email sending failed (check SMTP settings) — here's the link to share manually: ${data.activationUrl}`
      );
      load();
    } catch (err) {
      setNote(err instanceof Error ? err.message : 'Failed.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleCopy(token: string) {
    await navigator.clipboard.writeText(activationUrl(token));
    setNote('Activation link copied to clipboard.');
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">AIPeT — Students</h1>
      <p className="mt-1 max-w-2xl text-sm text-mist-400">
        A student stuck on &quot;pending activation&quot; usually means the activation email didn&apos;t
        send (SMTP not configured, or a spam filter). Use Copy link / Resend below instead of waiting on email.
      </p>

      {note && <p className="mt-4 rounded-lg border border-teal-600/30 bg-teal-600/10 p-3 text-sm text-teal-300">{note}</p>}
      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      <div className="mt-6 overflow-x-auto rounded-brand border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-mist-400">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Account</th>
              <th className="px-4 py-3">Access</th>
              <th className="px-4 py-3">Until</th>
              <th className="px-4 py-3">Joined</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {students?.map((s) => {
              const access = computeAccess(s);
              return (
                <tr key={s.id} className="border-t border-white/5 align-top">
                  <td className="px-4 py-3 text-white">{s.fullName}</td>
                  <td className="px-4 py-3 text-mist-400">{s.email}</td>
                  <td className="px-4 py-3 text-mist-400">{s.status}</td>
                  <td className={`px-4 py-3 ${access.color}`}>{access.label}</td>
                  <td className="px-4 py-3 text-mist-400">
                    {access.until ? new Date(access.until).toLocaleDateString() : '—'}
                  </td>
                  <td className="px-4 py-3 text-mist-400">{new Date(s.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    {s.status !== 'ACTIVE' && (
                      <div className="flex flex-col gap-1">
                        <button onClick={() => handleCopy(s.activationToken)} className="text-xs text-teal-400 hover:underline">
                          Copy activation link
                        </button>
                        <button
                          onClick={() => handleResend(s.id)}
                          disabled={busyId === s.id}
                          className="text-xs text-gold-500 hover:underline disabled:opacity-50"
                        >
                          {busyId === s.id ? 'Sending…' : 'Resend email'}
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
            {students?.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-6 text-center text-mist-400">
                  No students yet.
                </td>
              </tr>
            )}
            {!students && !error && (
              <tr>
                <td colSpan={7} className="px-4 py-6 text-center text-mist-400">
                  Loading…
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
