import Link from 'next/link';
import { prisma } from '@/lib/db';
import DeleteButton from '@/components/admin/DeleteButton';

export default async function AdminAipetModulesPage() {
  const modules = await prisma.aipetModule.findMany({ orderBy: { order: 'asc' }, include: { units: true } });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">AIPeT — Modules</h1>
        <Link href="/admin/aipet/modules/new" className="btn-primary">Add module</Link>
      </div>
      <p className="mt-1 text-sm text-mist-400">
        A module groups units (e.g. "Mathematics", "Cybersecurity fundamentals", "AI basics").
        Add as many as you like — this is where new subjects/modules are managed.
      </p>

      <div className="mt-6 overflow-hidden rounded-brand border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-mist-400">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Slug</th>
              <th className="px-4 py-3">Units</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {modules.map((m) => (
              <tr key={m.id} className="border-t border-white/5">
                <td className="px-4 py-3 text-white">{m.nameEn}</td>
                <td className="px-4 py-3 text-mist-400">{m.slug}</td>
                <td className="px-4 py-3 text-mist-400">{m.units.length}</td>
                <td className="px-4 py-3 text-mist-400">{m.status}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/aipet/modules/${m.id}`} className="mr-3 text-teal-400 hover:text-teal-300">Edit</Link>
                  <DeleteButton endpoint={`/api/admin/aipet/modules/${m.id}`} />
                </td>
              </tr>
            ))}
            {modules.length === 0 && <tr><td colSpan={5} className="px-4 py-6 text-center text-mist-400">No modules yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
