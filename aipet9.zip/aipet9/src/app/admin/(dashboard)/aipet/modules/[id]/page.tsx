import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import ModuleForm from '@/components/admin/ModuleForm';

export default async function EditAipetModulePage({ params }: { params: { id: string } }) {
  const module_ = await prisma.aipetModule.findUnique({ where: { id: params.id } });
  if (!module_) notFound();

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Edit module</h1>
      <div className="mt-6">
        <ModuleForm
          initial={{
            id: module_.id,
            slug: module_.slug,
            nameEn: module_.nameEn,
            nameAr: module_.nameAr,
            descriptionEn: module_.descriptionEn ?? '',
            descriptionAr: module_.descriptionAr ?? '',
            order: module_.order,
            status: module_.status,
          }}
        />
      </div>
    </div>
  );
}
