import ModuleForm from '@/components/admin/ModuleForm';

export default function NewAipetModulePage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Add module</h1>
      <div className="mt-6"><ModuleForm /></div>
    </div>
  );
}
