import Link from 'next/link';
import { prisma } from '@/lib/db';
import DeleteButton from '@/components/admin/DeleteButton';

export default async function AdminAipetUnitsPage() {
  const units = await prisma.aipetUnit.findMany({
    orderBy: [{ moduleId: 'asc' }, { order: 'asc' }],
    include: { module: true, exercises: true },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">AIPeT — Units</h1>
        <Link href="/admin/aipet/units/new" className="btn-primary">Add unit</Link>
      </div>

      <div className="mt-6 overflow-hidden rounded-brand border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-mist-400">
            <tr>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Module</th>
              <th className="px-4 py-3">Exercises</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {units.map((u) => (
              <tr key={u.id} className="border-t border-white/5">
                <td className="px-4 py-3 text-white">{u.titleEn}</td>
                <td className="px-4 py-3 text-mist-400">{u.module.nameEn}</td>
                <td className="px-4 py-3 text-mist-400">{u.exercises.length}</td>
                <td className="px-4 py-3 text-mist-400">{u.status}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/aipet/units/${u.id}`} className="mr-3 text-teal-400 hover:text-teal-300">Edit</Link>
                  <DeleteButton endpoint={`/api/admin/aipet/units/${u.id}`} />
                </td>
              </tr>
            ))}
            {units.length === 0 && <tr><td colSpan={5} className="px-4 py-6 text-center text-mist-400">No units yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
