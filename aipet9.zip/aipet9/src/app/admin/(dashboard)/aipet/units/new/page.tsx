import { prisma } from '@/lib/db';
import UnitForm from '@/components/admin/UnitForm';

export default async function NewAipetUnitPage() {
  const modules = await prisma.aipetModule.findMany({ orderBy: { order: 'asc' }, select: { id: true, nameEn: true } });
  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Add unit</h1>
      {modules.length === 0 ? (
        <p className="mt-4 text-mist-400">Create a module first under AIPeT → Modules.</p>
      ) : (
        <div className="mt-6"><UnitForm modules={modules} /></div>
      )}
    </div>
  );
}
