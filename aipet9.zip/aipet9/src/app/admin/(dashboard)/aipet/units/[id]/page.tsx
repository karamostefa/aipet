import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import UnitForm from '@/components/admin/UnitForm';

export default async function EditAipetUnitPage({ params }: { params: { id: string } }) {
  const [unit, modules] = await Promise.all([
    prisma.aipetUnit.findUnique({ where: { id: params.id } }),
    prisma.aipetModule.findMany({ orderBy: { order: 'asc' }, select: { id: true, nameEn: true } }),
  ]);
  if (!unit) notFound();

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Edit unit</h1>
      <div className="mt-6">
        <UnitForm
          modules={modules}
          initial={{
            id: unit.id,
            moduleId: unit.moduleId,
            titleEn: unit.titleEn,
            titleAr: unit.titleAr,
            descriptionEn: unit.descriptionEn ?? '',
            descriptionAr: unit.descriptionAr ?? '',
            order: unit.order,
            status: unit.status,
          }}
        />
      </div>
    </div>
  );
}
