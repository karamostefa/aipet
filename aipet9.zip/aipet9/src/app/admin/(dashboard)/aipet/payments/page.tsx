import { prisma } from '@/lib/db';
import { PLAN_LABELS } from '@/lib/subscription';

const statusColor: Record<string, string> = {
  PAID: 'text-teal-400',
  PENDING: 'text-gold-500',
  FAILED: 'text-red-400',
};

export default async function AdminAipetPaymentsPage() {
  const payments = await prisma.aipetPayment.findMany({
    orderBy: { createdAt: 'desc' },
    include: { student: { select: { fullName: true, email: true } } },
    take: 200,
  });

  const totalPaidDzd = payments
    .filter((p) => p.status === 'PAID')
    .reduce((sum, p) => sum + Number(p.amountDzd), 0);

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">AIPeT — Payments</h1>
        <p className="text-sm text-mist-400">
          Total collected: <span className="text-white">{totalPaidDzd.toLocaleString('en-US')} DZD</span>
        </p>
      </div>
      <p className="mt-1 text-sm text-mist-400">
        Payments are created when a student clicks Subscribe, and marked PAID only by a verified
        Chargily webhook — never by the success-page redirect alone (see SECURITY.md).
      </p>

      <div className="mt-6 overflow-hidden rounded-brand border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-mist-400">
            <tr>
              <th className="px-4 py-3">Student</th>
              <th className="px-4 py-3">Plan</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Created</th>
              <th className="px-4 py-3">Paid</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-t border-white/5">
                <td className="px-4 py-3 text-white">
                  {p.student.fullName}
                  <div className="text-xs text-mist-400">{p.student.email}</div>
                </td>
                <td className="px-4 py-3 text-mist-400">{PLAN_LABELS[p.plan].en}</td>
                <td className="px-4 py-3 text-mist-400">{Number(p.amountDzd).toLocaleString('en-US')} DZD</td>
                <td className={`px-4 py-3 ${statusColor[p.status]}`}>{p.status}</td>
                <td className="px-4 py-3 text-mist-400">{p.createdAt.toLocaleString('en-US')}</td>
                <td className="px-4 py-3 text-mist-400">{p.paidAt ? p.paidAt.toLocaleString('en-US') : '—'}</td>
              </tr>
            ))}
            {payments.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-6 text-center text-mist-400">
                  No payments yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
