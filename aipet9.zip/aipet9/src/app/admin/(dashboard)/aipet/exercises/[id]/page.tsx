import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';
import ExerciseForm from '@/components/admin/ExerciseForm';

export default async function EditAipetExercisePage({ params }: { params: { id: string } }) {
  const [exercise, units] = await Promise.all([
    prisma.aipetExercise.findUnique({ where: { id: params.id } }),
    prisma.aipetUnit.findMany({ orderBy: { order: 'asc' }, include: { module: true } }),
  ]);
  if (!exercise) notFound();
  const options = units.map((u) => ({ id: u.id, titleEn: u.titleEn, moduleName: u.module.nameEn }));

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Edit exercise</h1>
      <div className="mt-6">
        <ExerciseForm
          units={options}
          initial={{
            id: exercise.id,
            unitId: exercise.unitId,
            number: exercise.number,
            difficulty: exercise.difficulty,
            statementEn: exercise.statementEn,
            statementAr: exercise.statementAr,
            officialSolutionEn: exercise.officialSolutionEn,
            officialSolutionAr: exercise.officialSolutionAr,
            solutionStepsEn: exercise.solutionStepsEn,
            solutionStepsAr: exercise.solutionStepsAr,
            keyConceptsEn: exercise.keyConceptsEn ?? '',
            keyConceptsAr: exercise.keyConceptsAr ?? '',
            commonMistakesEn: exercise.commonMistakesEn ?? '',
            commonMistakesAr: exercise.commonMistakesAr ?? '',
            status: exercise.status,
          }}
        />
      </div>
    </div>
  );
}
