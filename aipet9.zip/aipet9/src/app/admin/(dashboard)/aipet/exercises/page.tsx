import Link from 'next/link';
import { prisma } from '@/lib/db';
import DeleteButton from '@/components/admin/DeleteButton';

export default async function AdminAipetExercisesPage() {
  const exercises = await prisma.aipetExercise.findMany({
    orderBy: [{ unitId: 'asc' }, { number: 'asc' }],
    include: { unit: { include: { module: true } } },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">AIPeT — Exercises</h1>
        <Link href="/admin/aipet/exercises/new" className="btn-primary">Add exercise</Link>
      </div>
      <p className="mt-1 text-sm text-mist-400">
        This is where you add more exercises, solutions, and step-breakdowns —
        the more detail here, the sharper AIPeT's tutoring will be.
      </p>

      <div className="mt-6 overflow-hidden rounded-brand border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-mist-400">
            <tr>
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Unit</th>
              <th className="px-4 py-3">Module</th>
              <th className="px-4 py-3">Difficulty</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {exercises.map((ex) => (
              <tr key={ex.id} className="border-t border-white/5">
                <td className="px-4 py-3 text-white">{ex.number}</td>
                <td className="px-4 py-3 text-mist-400">{ex.unit.titleEn}</td>
                <td className="px-4 py-3 text-mist-400">{ex.unit.module.nameEn}</td>
                <td className="px-4 py-3 text-mist-400">{ex.difficulty}</td>
                <td className="px-4 py-3 text-mist-400">{ex.status}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/aipet/exercises/${ex.id}`} className="mr-3 text-teal-400 hover:text-teal-300">Edit</Link>
                  <DeleteButton endpoint={`/api/admin/aipet/exercises/${ex.id}`} />
                </td>
              </tr>
            ))}
            {exercises.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-mist-400">No exercises yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
