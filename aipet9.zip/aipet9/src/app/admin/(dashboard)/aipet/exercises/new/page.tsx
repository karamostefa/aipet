import { prisma } from '@/lib/db';
import ExerciseForm from '@/components/admin/ExerciseForm';

export default async function NewAipetExercisePage() {
  const units = await prisma.aipetUnit.findMany({
    orderBy: { order: 'asc' },
    include: { module: true },
  });
  const options = units.map((u) => ({ id: u.id, titleEn: u.titleEn, moduleName: u.module.nameEn }));

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">Add exercise</h1>
      {options.length === 0 ? (
        <p className="mt-4 text-mist-400">Create a unit first under AIPeT → Units.</p>
      ) : (
        <div className="mt-6"><ExerciseForm units={options} /></div>
      )}
    </div>
  );
}
