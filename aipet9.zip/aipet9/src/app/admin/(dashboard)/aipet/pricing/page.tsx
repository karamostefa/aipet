'use client';

import { useEffect, useState } from 'react';
import { PLAN_LABELS, type Plan } from '@/lib/subscriptionPlans';

const PLANS: Plan[] = ['MONTHLY', 'TRIMESTER', 'ANNUAL'];

export default function AdminPricingPage() {
  const [prices, setPrices] = useState<Record<Plan, number> | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/admin/aipet/pricing')
      .then((res) => res.json())
      .then(setPrices)
      .catch(() => setError('Could not load current prices.'));
  }, []);

  async function handleSave() {
    if (!prices) return;
    setSaving(true);
    setError(null);
    setMessage(null);
    try {
      const res = await fetch('/api/admin/aipet/pricing', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prices),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save.');
      setPrices(data);
      setMessage('Prices updated. Students will see the new prices immediately on /aipet/subscribe.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-white">AIPeT — Pricing</h1>
      <p className="mt-1 max-w-xl text-sm text-mist-400">
        Prices shown to students on /aipet/subscribe and charged via Chargily. Changing a price here only
        affects future checkouts — it never changes what an already-paying student was charged.
      </p>

      {!prices ? (
        <p className="mt-6 text-mist-400">Loading…</p>
      ) : (
        <div className="mt-6 max-w-md space-y-4">
          {PLANS.map((plan) => (
            <label key={plan} className="block">
              <span className="text-sm text-mist-400">{PLAN_LABELS[plan].en} (DZD)</span>
              <input
                type="number"
                min={1}
                step={1}
                value={prices[plan]}
                onChange={(e) => setPrices({ ...prices, [plan]: Number(e.target.value) })}
                className="mt-1 w-full rounded-lg border border-white/10 bg-ink-900 px-3 py-2 text-white"
              />
            </label>
          ))}

          <button onClick={handleSave} disabled={saving} className="btn-primary disabled:opacity-60">
            {saving ? 'Saving…' : 'Save prices'}
          </button>

          {message && <p className="text-sm text-teal-400">{message}</p>}
          {error && <p className="text-sm text-red-400">{error}</p>}
        </div>
      )}
    </div>
  );
}
