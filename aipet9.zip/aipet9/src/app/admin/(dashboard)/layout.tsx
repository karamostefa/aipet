import type { ReactNode } from 'react';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getCurrentAdmin } from '@/lib/auth';
import AdminLogoutButton from '@/components/admin/AdminLogoutButton';

const NAV = [
  { href: '/admin', label: 'Dashboard' },
  { href: '/admin/aipet/modules', label: 'Modules' },
  { href: '/admin/aipet/units', label: 'Units' },
  { href: '/admin/aipet/exercises', label: 'Exercises' },
  { href: '/admin/aipet/pricing', label: 'Pricing' },
  { href: '/admin/aipet/students', label: 'Students' },
  { href: '/admin/aipet/payments', label: 'Payments' },
];

// This layout — not just middleware.ts — is the PRIMARY auth check for
// every authenticated admin page. It always runs in the Node.js runtime
// (Server Components never run on the Edge Runtime the way Middleware
// can), so it's the one place we can be fully certain the session check
// actually executes. Middleware is a fast first line of defense for a
// better redirect experience; this is the real gate.
//
// This layout only wraps pages inside the (dashboard) route group — NOT
// /admin/login, which sits outside that group specifically so it never
// gets wrapped in this sidebar. (Route groups — the parens in the folder
// name — don't affect the URL, only which layout applies.)
export default async function AdminDashboardLayout({ children }: { children: ReactNode }) {
  const admin = await getCurrentAdmin();
  if (!admin) redirect('/admin/login');

  return (
    <div className="flex min-h-screen bg-ink-950 text-mist-200">
      <aside className="w-64 shrink-0 border-r border-white/5 bg-ink-900 p-6">
        <p className="font-display text-lg font-semibold text-white">AIPeT Admin</p>
        <p className="mt-1 truncate text-xs text-mist-400">{admin.email}</p>
        <nav className="mt-8 space-y-1">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href}
              className="block rounded-lg px-3 py-2 text-sm text-mist-400 transition hover:bg-white/5 hover:text-white">
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="mt-8">
          <AdminLogoutButton />
        </div>
      </aside>
      <main className="flex-1 p-8">{children}</main>
    </div>
  );
}
