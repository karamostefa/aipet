import type { ReactNode } from 'react';
import type { Metadata } from 'next';
import '../globals.css';

export const metadata: Metadata = {
  title: 'AIPeT Admin',
  robots: { index: false, follow: false }, // never let search engines index the admin panel
};

// This is the ONLY place that renders <html>/<body> for anything under
// /admin/* (both /admin/login and everything in the (dashboard) route
// group). The root layout (src/app/layout.tsx) is intentionally a
// passthrough — its <html>/<body> lives in src/app/[locale]/layout.tsx
// instead, since it needs the locale param for lang/dir. But /admin/*
// isn't nested under [locale] at all, so without this file, admin routes
// had no <html>/<body> anywhere in their render chain — which is exactly
// what "Missing <html> and <body> tags in the root layout" means. The
// (dashboard) layout nested inside this one only adds the sidebar UI; it
// was never meant to (and doesn't) provide html/body itself.
export default function AdminRootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
