import Link from 'next/link';
import { defaultLocale } from '@/i18n/config';
import './globals.css';

// Root-level not-found.tsx. Next.js renders this through the ROOT layout
// only (src/app/layout.tsx, which is intentionally just a passthrough —
// see that file) whenever a route fails to resolve *before* reaching the
// nested [locale] layout that normally provides <html>/<body>. Genuinely
// invalid paths (a bad locale segment, a typo'd URL) hit exactly that
// case, so this file needs its own <html>/<body> rather than relying on
// the nested layout, or Next throws "Missing <html> and <body> tags".
export default function NotFound() {
  return (
    <html lang="en">
      <body>
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '1rem', fontFamily: 'sans-serif' }}>
          <h1 style={{ fontSize: '1.5rem' }}>Page not found</h1>
          <Link href={`/${defaultLocale}/aipet`} style={{ color: '#2FA79B' }}>
            Go to AIPeT
          </Link>
        </div>
      </body>
    </html>
  );
}
