import { redirect, notFound } from 'next/navigation';
import { isValidLocale, type Locale } from '@/i18n/config';
import { getCurrentStudent } from '@/lib/studentAuth';
import { prisma } from '@/lib/db';
import { checkAccess } from '@/lib/subscription';
import ExercisePractice from '@/components/ExercisePractice';

export default async function ExercisePage({ params }: { params: { locale: string; id: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const session = await getCurrentStudent();
  if (!session) redirect(`/${locale}/aipet/login`);

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: session!.studentId } });
  if (!student) redirect(`/${locale}/aipet/login`);
  if (!checkAccess(student).hasAccess) redirect(`/${locale}/aipet/subscribe`);

  // Deliberately select only the statement — the official solution, steps,
  // and common mistakes never leave the server; the tutor API route reads
  // them directly from the database when it calls Claude.
  const exercise = await prisma.aipetExercise.findUnique({
    where: { id: params.id },
    select: { id: true, number: true, difficulty: true, statementEn: true, statementAr: true, status: true },
  });
  if (!exercise || exercise.status !== 'PUBLISHED') notFound();

  return (
    <section className="section max-w-2xl">
      <span className="eyebrow">{locale === 'ar' ? 'تمرين' : 'Exercise'} {exercise.number}</span>
      <h1 className="text-2xl font-semibold text-white">
        {locale === 'ar' ? exercise.statementAr : exercise.statementEn}
      </h1>

      <ExercisePractice locale={locale} exerciseId={exercise.id} />
    </section>
  );
}
