import Link from 'next/link';
import { redirect, notFound } from 'next/navigation';
import { isValidLocale, type Locale } from '@/i18n/config';
import { getCurrentStudent } from '@/lib/studentAuth';
import { prisma } from '@/lib/db';
import { checkAccess } from '@/lib/subscription';

const difficultyColor: Record<string, string> = {
  EASY: 'text-teal-400',
  MEDIUM: 'text-gold-500',
  HARD: 'text-violet-400',
};

export default async function AipetUnitPage({ params }: { params: { locale: string; id: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const session = await getCurrentStudent();
  if (!session) redirect(`/${locale}/aipet/login`);

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: session!.studentId } });
  if (!student) redirect(`/${locale}/aipet/login`);
  if (!checkAccess(student).hasAccess) redirect(`/${locale}/aipet/subscribe`);

  const unit = await prisma.aipetUnit.findUnique({
    where: { id: params.id },
    include: { exercises: { where: { status: 'PUBLISHED' }, orderBy: { number: 'asc' } }, module: true },
  });
  if (!unit || unit.status !== 'PUBLISHED') notFound();

  const mySubmissions = await prisma.submission.findMany({
    where: { studentId: student.id, exercise: { unitId: unit.id } },
    select: { exerciseId: true, score: true },
  });
  const bestByExercise = new Map<string, number>();
  for (const s of mySubmissions) {
    if (s.score != null) bestByExercise.set(s.exerciseId, Math.max(bestByExercise.get(s.exerciseId) ?? 0, s.score));
  }

  return (
    <section className="section">
      <span className="eyebrow">{locale === 'ar' ? unit.module.nameAr : unit.module.nameEn}</span>
      <h1 className="text-3xl font-semibold text-white">{locale === 'ar' ? unit.titleAr : unit.titleEn}</h1>
      <p className="mt-2 max-w-2xl text-mist-400">{locale === 'ar' ? unit.descriptionAr : unit.descriptionEn}</p>

      <div className="mt-8 space-y-3">
        {unit.exercises.map((ex) => {
          const best = bestByExercise.get(ex.id);
          return (
            <Link key={ex.id} href={`/${locale}/aipet/exercise/${ex.id}`}
              className="card flex items-center justify-between !p-5">
              <div>
                <p className="font-semibold text-white">
                  {locale === 'ar' ? 'تمرين' : 'Exercise'} {ex.number}
                </p>
                <p className={`text-xs uppercase tracking-wide ${difficultyColor[ex.difficulty]}`}>{ex.difficulty}</p>
              </div>
              <div className="text-right text-sm">
                {best != null ? (
                  <span className="text-teal-400">{best}%</span>
                ) : (
                  <span className="text-mist-400">{locale === 'ar' ? 'لم يبدأ' : 'Not attempted'}</span>
                )}
              </div>
            </Link>
          );
        })}
        {unit.exercises.length === 0 && <p className="text-mist-400">No exercises published in this unit yet.</p>}
      </div>
    </section>
  );
}
