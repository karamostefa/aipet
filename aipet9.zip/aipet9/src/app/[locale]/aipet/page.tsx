import { isValidLocale, type Locale } from '@/i18n/config';
import { getDictionary } from '@/i18n/getDictionary';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import AipetSignupForm from '@/components/AipetSignupForm';

export default async function AipetPage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const dict = await getDictionary(locale);

  const steps = [dict.aipet.how1, dict.aipet.how2, dict.aipet.how3, dict.aipet.how4];

  return (
    <>
      <section className="section border-b border-white/5 bg-ink-gradient text-center">
        <span className="eyebrow">AIPeT</span>
        <h1 className="mx-auto max-w-2xl text-4xl font-semibold text-white">{dict.aipet.title}</h1>
        <p className="mx-auto mt-4 max-w-xl text-lg text-mist-400">{dict.aipet.subtitle}</p>
      </section>

      <section className="section">
        <h2 className="text-2xl font-semibold text-white">{dict.aipet.howTitle}</h2>
        <ol className="mt-6 space-y-4">
          {steps.map((step: string, i: number) => (
            <li key={i} className="card flex gap-4">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-violet-500/20 font-semibold text-violet-400">
                {i + 1}
              </span>
              <p className="text-mist-400">{step}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="section max-w-lg border-t border-white/5">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-white">{dict.aipet.signUp}</h2>
          <Link href={`/${locale}/aipet/login`} className="text-sm text-teal-400 hover:text-teal-300">
            {locale === 'ar' ? 'لديك حساب؟ سجّل الدخول' : 'Already have an account? Log in'}
          </Link>
        </div>
        <p className="mt-2 text-sm text-mist-400">{dict.aipet.activationNote}</p>
        <AipetSignupForm dict={dict} />
      </section>
    </>
  );
}
