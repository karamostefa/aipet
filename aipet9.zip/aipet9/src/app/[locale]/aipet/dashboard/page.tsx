import Link from 'next/link';
import { redirect } from 'next/navigation';
import { isValidLocale, type Locale } from '@/i18n/config';
import { notFound } from 'next/navigation';
import { getCurrentStudent } from '@/lib/studentAuth';
import { prisma } from '@/lib/db';
import { checkAccess } from '@/lib/subscription';
import AipetLogoutButton from '@/components/AipetLogoutButton';

export default async function AipetDashboardPage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const session = await getCurrentStudent();
  if (!session) redirect(`/${locale}/aipet/login`);

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: session!.studentId } });
  if (!student) redirect(`/${locale}/aipet/login`);

  const access = checkAccess(student);
  if (!access.hasAccess) redirect(`/${locale}/aipet/subscribe`);

  const daysLeft = access.accessUntil
    ? Math.max(0, Math.ceil((access.accessUntil.getTime() - Date.now()) / (24 * 60 * 60 * 1000)))
    : null;

  const modules = await prisma.aipetModule.findMany({
    where: { status: 'PUBLISHED' },
    orderBy: { order: 'asc' },
    include: { units: { where: { status: 'PUBLISHED' }, orderBy: { order: 'asc' } } },
  });

  const progress = await prisma.progress.findMany({ where: { studentId: student.id } });
  const progressByUnit = Object.fromEntries(progress.map((p) => [p.unitId, p]));

  return (
    <section className="section">
      <div className="flex items-center justify-between">
        <div>
          <span className="eyebrow">AIPeT</span>
          <h1 className="text-3xl font-semibold text-white">
            {locale === 'ar' ? `مرحباً، ${student.fullName}` : `Welcome back, ${student.fullName}`}
          </h1>
        </div>
        <AipetLogoutButton locale={locale} />
      </div>

      {access.reason === 'trial' && daysLeft !== null && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-brand border border-gold-500/30 bg-gold-500/10 p-4 text-sm text-gold-500">
          <span>
            {locale === 'ar'
              ? `تبقى لك ${daysLeft} يوم/أيام من فترتك المجانية.`
              : `${daysLeft} day${daysLeft === 1 ? '' : 's'} left in your free trial.`}
          </span>
          <Link href={`/${locale}/aipet/subscribe`} className="btn-secondary !px-4 !py-2 text-xs">
            {locale === 'ar' ? 'اشترك الآن' : 'Subscribe now'}
          </Link>
        </div>
      )}

      <div className="mt-10 space-y-10">
        {modules.map((mod) => (
          <div key={mod.id}>
            <h2 className="text-xl font-semibold text-white">{locale === 'ar' ? mod.nameAr : mod.nameEn}</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {mod.units.map((unit) => {
                const p = progressByUnit[unit.id];
                const pct = p && p.exercisesAttempted > 0 ? Math.round((p.exercisesMastered / p.exercisesAttempted) * 100) : 0;
                return (
                  <Link key={unit.id} href={`/${locale}/aipet/units/${unit.id}`} className="card block">
                    <h3 className="font-semibold text-white">{locale === 'ar' ? unit.titleAr : unit.titleEn}</h3>
                    <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-white/10">
                      <div className="h-full bg-gradient-to-r from-teal-600 to-teal-400" style={{ width: `${pct}%` }} />
                    </div>
                    <p className="mt-2 text-xs text-mist-400">
                      {p ? `${p.exercisesMastered}/${p.exercisesAttempted} mastered` : 'Not started yet'}
                    </p>
                  </Link>
                );
              })}
              {mod.units.length === 0 && <p className="text-sm text-mist-400">No units published yet.</p>}
            </div>
          </div>
        ))}
        {modules.length === 0 && <p className="text-mist-400">No modules published yet — check back soon.</p>}
      </div>
    </section>
  );
}
