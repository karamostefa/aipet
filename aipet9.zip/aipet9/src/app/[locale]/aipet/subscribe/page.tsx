import { redirect, notFound } from 'next/navigation';
import { isValidLocale, type Locale } from '@/i18n/config';
import { getCurrentStudent } from '@/lib/studentAuth';
import { prisma } from '@/lib/db';
import { checkAccess, getPlanPrices } from '@/lib/subscription';
import SubscribeForm from '@/components/SubscribeForm';

export default async function SubscribePage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const session = await getCurrentStudent();
  if (!session) redirect(`/${locale}/aipet/login`);

  const student = await prisma.aipetSubscriber.findUnique({ where: { id: session.studentId } });
  if (!student) redirect(`/${locale}/aipet/login`);

  const access = checkAccess(student);
  const prices = await getPlanPrices();

  return (
    <section className="section max-w-3xl">
      <span className="eyebrow">AIPeT</span>
      <h1 className="text-3xl font-semibold text-white">
        {locale === 'ar' ? 'اختر خطة اشتراكك' : 'Choose your subscription'}
      </h1>
      <p className="mt-2 max-w-xl text-mist-400">
        {access.hasAccess && access.reason === 'trial'
          ? locale === 'ar'
            ? `تبقى لك وصول مجاني حتى ${access.accessUntil?.toLocaleDateString()}. يمكنك الاشتراك الآن لمواصلة الوصول بلا انقطاع بعد ذلك.`
            : `You still have free access until ${access.accessUntil?.toLocaleDateString()}. Subscribe now to keep uninterrupted access after that.`
          : locale === 'ar'
            ? 'انتهت فترتك المجانية أو اشتراكك. اختر خطة لمواصلة استخدام AIPeT.'
            : 'Your free trial or subscription has ended. Pick a plan to keep using AIPeT.'}
      </p>

      <SubscribeForm locale={locale} prices={prices} />
    </section>
  );
}
