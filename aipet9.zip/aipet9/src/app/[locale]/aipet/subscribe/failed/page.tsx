import Link from 'next/link';
import { isValidLocale, type Locale } from '@/i18n/config';
import { notFound } from 'next/navigation';

export default function SubscribeFailedPage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;

  return (
    <section className="section max-w-lg text-center">
      <h1 className="text-3xl font-semibold text-white">
        {locale === 'ar' ? 'فشلت عملية الدفع' : 'Payment did not go through'}
      </h1>
      <p className="mt-4 text-mist-400">
        {locale === 'ar'
          ? 'لم يتم خصم أي مبلغ. يمكنك إعادة المحاولة في أي وقت.'
          : "You haven't been charged. You can try again anytime."}
      </p>
      <Link href={`/${locale}/aipet/subscribe`} className="btn-secondary mt-8 inline-flex">
        {locale === 'ar' ? 'حاول مرة أخرى' : 'Try again'}
      </Link>
    </section>
  );
}
