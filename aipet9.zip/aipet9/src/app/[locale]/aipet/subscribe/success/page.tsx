import Link from 'next/link';
import { isValidLocale, type Locale } from '@/i18n/config';
import { notFound } from 'next/navigation';

export default function SubscribeSuccessPage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;

  return (
    <section className="section max-w-lg text-center">
      <h1 className="text-3xl font-semibold text-white">
        {locale === 'ar' ? 'تم الدفع بنجاح' : 'Payment received'}
      </h1>
      <p className="mt-4 text-mist-400">
        {locale === 'ar'
          ? 'شكراً لك. قد يستغرق تفعيل اشتراكك بضع دقائق أثناء تأكيد الدفع.'
          : "Thank you. Your subscription may take a couple of minutes to activate while the payment is confirmed."}
      </p>
      <Link href={`/${locale}/aipet/dashboard`} className="btn-secondary mt-8 inline-flex">
        {locale === 'ar' ? 'الذهاب إلى لوحتي' : 'Go to my dashboard'}
      </Link>
    </section>
  );
}
