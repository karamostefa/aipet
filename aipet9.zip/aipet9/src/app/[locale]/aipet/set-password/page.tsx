'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

export default function SetPasswordPage({ params }: { params: { locale: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token') || '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/aipet/set-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong.');
      router.push(`/${params.locale}/aipet/dashboard`);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
      setLoading(false);
    }
  }

  if (!token) {
    return (
      <section className="section max-w-sm text-center">
        <p className="text-mist-400">Missing activation token. Please use the link from your email.</p>
        <Link href={`/${params.locale}/aipet`} className="btn-secondary mt-6 inline-flex">Back</Link>
      </section>
    );
  }

  return (
    <section className="section max-w-sm">
      <h1 className="text-2xl font-semibold text-white">Choose your password</h1>
      <p className="mt-2 text-sm text-mist-400">This activates your AIPeT account.</p>
      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Password</label>
          <input required type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Confirm password</label>
          <input required type="password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
        </div>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
          {loading ? 'Activating…' : 'Activate my account'}
        </button>
      </form>
    </section>
  );
}
