import { redirect, notFound } from 'next/navigation';
import { isValidLocale } from '@/i18n/config';

// This app has no separate marketing homepage — /aipet under each locale
// IS the homepage. This route only exists so visiting the bare locale
// root (/en, /ar) — from a bookmark, browser autocomplete, back button,
// etc. — redirects somewhere real instead of 404ing (which, upstream of
// this fix, was also breaking html/body rendering — see src/app/layout.tsx).
export default function LocaleRootPage({ params }: { params: { locale: string } }) {
  if (!isValidLocale(params.locale)) notFound();
  redirect(`/${params.locale}/aipet`);
}
