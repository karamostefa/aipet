import type { ReactNode } from 'react';
import type { Metadata } from 'next';
import { locales, isValidLocale, localeDirection, type Locale } from '@/i18n/config';
import { getDictionary } from '@/i18n/getDictionary';
import { displayFont, bodyFont, monoFont, displayFontAr, bodyFontAr } from '@/app/fonts';
import { getCurrentStudent } from '@/lib/studentAuth';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { notFound } from 'next/navigation';
import '../globals.css';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: { locale: string };
}): Promise<Metadata> {
  return {
    title: 'AIPeT — AI Pedagogical Tutor',
    description:
      params.locale === 'ar'
        ? 'AIPeT مدرّس ذكاء اصطناعي تربوي لطلاب الثانوي في الجزائر — لا يعطي الحل، بل يعلّمك كيف تفكّر.'
        : 'AIPeT is an AI pedagogical tutor for Algerian high school students — it doesn\u2019t give you the answer, it teaches you how to think.',
    icons: { icon: '/logo/monogram.svg' },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: { locale: string };
}) {
  if (!isValidLocale(params.locale)) notFound();
  const locale = params.locale as Locale;
  const dict = await getDictionary(locale);
  const dir = localeDirection[locale];
  const fontVars =
    locale === 'ar'
      ? `${displayFontAr.variable} ${bodyFontAr.variable} ${monoFont.variable}`
      : `${displayFont.variable} ${bodyFont.variable} ${monoFont.variable}`;

  // Determines whether the header shows "Log in" or "Dashboard / Log out".
  // Reading the session here (not inside Header itself) is what makes
  // this correct even when a page is opened directly in a new tab —
  // Header previously always showed "Log in" regardless of actual state,
  // since it never checked the session at all.
  const session = await getCurrentStudent();

  return (
    <html lang={locale} dir={dir} className={fontVars}>
      <body>
        <Header locale={locale} dict={dict} isLoggedIn={!!session} />
        <main>{children}</main>
        <Footer locale={locale} dict={dict} />
      </body>
    </html>
  );
}
