// ------------------------------------------------------------------
// SERVER-ONLY subscription logic — imports Prisma and next/headers
// (via studentAuth.ts), so this file must NEVER be imported from a
// 'use client' component. Client components that only need the plan
// constants/types should import from src/lib/subscriptionPlans.ts
// instead — see that file's comment for why this split exists.
//
// Re-exports the plan constants here too, purely so existing
// server-side importers (page.tsx Server Components, API routes) can
// keep writing `import { PLAN_LABELS, checkAccess } from '@/lib/subscription'`
// in one line rather than importing from two files — that's fine, since
// those callers are never bundled for the client.
// ------------------------------------------------------------------

import { prisma } from '@/lib/db';
import { requireStudent } from '@/lib/studentAuth';
export * from '@/lib/subscriptionPlans';
import { DEFAULT_PLAN_PRICES_DZD, type Plan } from '@/lib/subscriptionPlans';

/**
 * Current, admin-editable DZD price for every plan. Reads the
 * AipetPricing table; any plan missing a row (shouldn't happen once
 * seeded, but data can always be deleted by hand) falls back to the
 * blueprint defaults above rather than crashing checkout.
 */
export async function getPlanPrices(): Promise<Record<Plan, number>> {
  const rows = await prisma.aipetPricing.findMany();
  const byPlan = Object.fromEntries(rows.map((r) => [r.plan, Number(r.priceDzd)])) as Partial<Record<Plan, number>>;
  return {
    MONTHLY: byPlan.MONTHLY ?? DEFAULT_PLAN_PRICES_DZD.MONTHLY,
    TRIMESTER: byPlan.TRIMESTER ?? DEFAULT_PLAN_PRICES_DZD.TRIMESTER,
    ANNUAL: byPlan.ANNUAL ?? DEFAULT_PLAN_PRICES_DZD.ANNUAL,
  };
}

interface AccessCheckInput {
  subscriptionStatus: string;
  trialEndsAt: Date | null;
  subscriptionExpiresAt: Date | null;
}

export interface AccessInfo {
  hasAccess: boolean;
  /** "trial" while inside the free trial window, "paid" while a subscription covers today, otherwise null. */
  reason: 'trial' | 'paid' | null;
  /** Whichever date access currently depends on (trial end or subscription end), if any. */
  accessUntil: Date | null;
}

/**
 * Single source of truth for "can this student use AIPeT right now?".
 * Used both by pages (to redirect to /aipet/subscribe) and by API routes
 * (to reject requests server-side — a page redirect alone isn't enough,
 * since API routes can be called directly).
 */
export function checkAccess(student: AccessCheckInput): AccessInfo {
  const now = new Date();

  if (
    student.subscriptionStatus === 'ACTIVE' &&
    student.subscriptionExpiresAt &&
    student.subscriptionExpiresAt > now
  ) {
    return { hasAccess: true, reason: 'paid', accessUntil: student.subscriptionExpiresAt };
  }

  if (student.subscriptionStatus === 'TRIALING' && student.trialEndsAt && student.trialEndsAt > now) {
    return { hasAccess: true, reason: 'trial', accessUntil: student.trialEndsAt };
  }

  return { hasAccess: false, reason: null, accessUntil: null };
}

/**
 * For use at the top of /api/aipet/* route handlers that require an
 * active (trialing or paid) student — not just a logged-in one. Page
 * loads redirect to /aipet/subscribe via checkAccess() above, but API
 * routes are called directly and must re-check server-side, the same
 * reason requireStudent() exists alongside getCurrentStudent().
 *
 * Returns the full subscriber row on success, or null if the caller
 * isn't logged in / doesn't currently have access.
 */
export async function requireActiveStudent() {
  const session = await requireStudent();
  if (!session) return null;
  const student = await prisma.aipetSubscriber.findUnique({ where: { id: session.studentId } });
  if (!student) return null;
  if (!checkAccess(student).hasAccess) return null;
  return student;
}
