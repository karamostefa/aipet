import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import type { NextRequest } from 'next/server';

// jose, same as src/lib/auth.ts — see that file's comment for why (Edge
// Runtime compatibility). Student sessions aren't currently checked in
// middleware, but keeping one consistent, fully-compatible JWT approach
// everywhere avoids this exact class of bug resurfacing if that changes.
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'dev-secret-change-me');
const STUDENT_SESSION_COOKIE = 'aipet_student_session';
const STUDENT_SESSION_TTL_SECONDS = 60 * 60 * 24 * 30; // 30 days — students stay logged in

export interface StudentSession {
  studentId: string;
  email: string;
  fullName: string;
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export async function signStudentSession(payload: StudentSession): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + STUDENT_SESSION_TTL_SECONDS)
    .sign(JWT_SECRET);
}

export async function verifyStudentSession(token: string): Promise<StudentSession | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as StudentSession;
  } catch {
    return null;
  }
}

/**
 * `isSecure` should reflect whether THIS specific request came in over
 * HTTPS (see requestIsHttps() below) — not NODE_ENV, which can be wrong
 * in some environments and would make the browser silently refuse to
 * store this cookie at all on plain HTTP. See src/lib/auth.ts for the
 * full explanation — this is the same fix, same reasoning.
 */
export function setStudentSessionCookie(token: string, isSecure: boolean) {
  cookies().set(STUDENT_SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isSecure,
    sameSite: 'strict',
    path: '/',
    maxAge: STUDENT_SESSION_TTL_SECONDS,
  });
}

export function clearStudentSessionCookie() {
  cookies().set(STUDENT_SESSION_COOKIE, '', { path: '/', maxAge: 0 });
}

/** Whether THIS request actually arrived over HTTPS — see src/lib/auth.ts's requestIsHttps() for details. */
export function requestIsHttps(req: NextRequest): boolean {
  if (req.nextUrl.protocol === 'https:') return true;
  return req.headers.get('x-forwarded-proto') === 'https';
}

/** For use in Server Components / pages: returns the logged-in student, or null. Always `await` this. */
export async function getCurrentStudent(): Promise<StudentSession | null> {
  const token = cookies().get(STUDENT_SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifyStudentSession(token);
}

/** For use inside /api/aipet/* route handlers that require a logged-in student. Always `await` this. */
export async function requireStudent(): Promise<StudentSession | null> {
  return getCurrentStudent();
}

export const STUDENT_SESSION_COOKIE_NAME = STUDENT_SESSION_COOKIE;
