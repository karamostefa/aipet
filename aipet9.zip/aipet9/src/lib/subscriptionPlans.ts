// ------------------------------------------------------------------
// Pure, client-safe subscription plan constants and types — NO imports
// of Prisma, next/headers, or anything else server-only. This is
// deliberately a separate file from src/lib/subscription.ts:
//
// Next.js bundles a client component's *entire* import graph for the
// browser. If a client component (e.g. src/components/SubscribeForm.tsx)
// imports ANYTHING from a file that also imports next/headers or Prisma
// — even just a constant — the whole module (including those server-only
// imports) gets pulled into the client bundle, and the build fails with
// "You're importing a component that needs next/headers." Splitting the
// client-safe exports (this file) from the server-only logic
// (src/lib/subscription.ts) is what fixes that class of bug for good,
// rather than just moving the one import that happened to trip over it.
//
// Rule of thumb: if a 'use client' component needs something from here,
// import it from THIS file, never from src/lib/subscription.ts directly.
// ------------------------------------------------------------------

export type Plan = 'MONTHLY' | 'TRIMESTER' | 'ANNUAL';

export const TRIAL_DAYS = 7;

// Used only (a) to seed the AipetPricing table on first run, and (b) as a
// safety-net fallback if that table is ever empty. The actual prices shown
// to students and charged via Chargily always come from getPlanPrices()
// in src/lib/subscription.ts, which reads the (admin-editable,
// /admin/aipet/pricing) database table — NOT this constant.
export const DEFAULT_PLAN_PRICES_DZD: Record<Plan, number> = {
  MONTHLY: 800,
  TRIMESTER: 2100,
  ANNUAL: 7500,
};

export const PLAN_DURATION_DAYS: Record<Plan, number> = {
  MONTHLY: 30,
  TRIMESTER: 90,
  ANNUAL: 365,
};

export const PLAN_LABELS: Record<Plan, { en: string; ar: string }> = {
  MONTHLY: { en: 'Monthly', ar: 'شهري' },
  TRIMESTER: { en: 'Trimester (3 months)', ar: 'فصلي (3 أشهر)' },
  ANNUAL: { en: 'Annual', ar: 'سنوي' },
};

export function isValidPlan(value: unknown): value is Plan {
  return value === 'MONTHLY' || value === 'TRIMESTER' || value === 'ANNUAL';
}
