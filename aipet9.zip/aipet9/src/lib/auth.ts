import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import type { NextRequest } from 'next/server';

// jose (not jsonwebtoken) deliberately — it works in BOTH the normal
// Node.js runtime (Server Components, Route Handlers) AND the Edge
// Runtime that Next.js Middleware runs on by default. jsonwebtoken
// depends on Node's `crypto` module, which isn't reliably available in
// Edge Runtime, so using it in middleware.ts silently undermined the
// whole point of checking auth there. jose uses the standard Web Crypto
// API instead, which both environments support.
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'dev-secret-change-me');
const SESSION_COOKIE = 'aipet_admin_session';
const SESSION_TTL_SECONDS = 60 * 60 * 8; // 8 hours

export interface AdminSession {
  adminId: string;
  email: string;
  role: 'SUPER_ADMIN' | 'CONTENT_ADMIN' | 'SUPPORT';
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export async function signSession(payload: AdminSession): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS)
    .sign(JWT_SECRET);
}

/** jose's verification is async everywhere (Web Crypto API is Promise-based) — every caller must `await` this. */
export async function verifySession(token: string): Promise<AdminSession | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as AdminSession;
  } catch {
    return null; // expired, tampered, or malformed — always fail closed
  }
}

/**
 * Sets the signed, httpOnly session cookie after a successful login.
 * `isSecure` should reflect whether THIS specific request actually came
 * in over HTTPS (see requestIsHttps() in this file) — not NODE_ENV.
 * Browsers refuse to store a cookie marked `Secure` on a plain HTTP
 * connection (including http://localhost), so if this were wrong in
 * either direction, login could appear to silently do nothing: the
 * server would report success, but the browser would just discard the
 * cookie, and every subsequent page load would look logged-out again.
 */
export function setSessionCookie(token: string, isSecure: boolean) {
  cookies().set(SESSION_COOKIE, token, {
    httpOnly: true, // not readable from client JS — blocks XSS token theft
    secure: isSecure,
    sameSite: 'strict', // blocks CSRF from third-party sites
    path: '/',
    maxAge: SESSION_TTL_SECONDS,
  });
}

export function clearSessionCookie() {
  // path must match what was set above, or the browser treats it as a
  // different cookie and won't actually remove the real session cookie.
  cookies().set(SESSION_COOKIE, '', { path: '/', maxAge: 0 });
}

/**
 * Whether THIS request actually arrived over HTTPS — checks the real
 * protocol first, then the standard reverse-proxy header (needed behind
 * Vercel/most hosts, where Next.js itself sees plain HTTP from the proxy
 * even though the browser connected via HTTPS). Deliberately NOT based
 * on NODE_ENV or any env var, both of which can be wrong for a given
 * environment and would make the Secure flag lie about the actual
 * connection — see setSessionCookie() above for what that breaks.
 */
export function requestIsHttps(req: NextRequest): boolean {
  if (req.nextUrl.protocol === 'https:') return true;
  return req.headers.get('x-forwarded-proto') === 'https';
}

/** Reads and verifies the current admin session, for use in Server Components / Route Handlers. */
export async function getCurrentAdmin(): Promise<AdminSession | null> {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySession(token);
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;

/**
 * Use at the top of every /api/admin/* route handler — `await` it. Next's
 * middleware also blocks unauthenticated *page* loads under /admin, but
 * (a) API routes are called directly (fetch) and need their own check
 * regardless, and (b) this is the check that actually matters most,
 * since it's the one guaranteed to run in the Node.js runtime.
 */
export async function requireAdmin(): Promise<AdminSession | null> {
  return getCurrentAdmin();
}
