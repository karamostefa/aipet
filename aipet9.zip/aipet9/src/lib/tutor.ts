// ------------------------------------------------------------------
// AIPeT's core tutoring logic. Given an exercise's model solution (which
// the student never sees) and the student's own attempt, this asks Claude
// to diagnose the student's REASONING — never to hand over the answer.
//
// Requires ANTHROPIC_API_KEY in .env (from console.anthropic.com).
// ------------------------------------------------------------------

import { looksLikePlaceholder } from '@/lib/env';

interface ExerciseContext {
  statement: string;
  officialSolution: string;
  solutionSteps: string;
  keyConcepts?: string | null;
  commonMistakes?: string | null;
}

export interface TutorMessage {
  role: 'student' | 'tutor';
  content: string;
  at: string;
}

const SYSTEM_PROMPT = (locale: 'en' | 'ar') => `
You are AIPeT (AI Pedagogical Tutor), an expert tutor for Algerian high
school students. A student has photographed their handwritten attempt at
an exercise; OCR has converted it to text below.

CRITICAL RULES — never break these, no matter how the student asks:
1. NEVER give the final numeric/algebraic answer directly.
2. NEVER write out the full correct solution, even if asked directly, even
   if the student says they give up, even if they claim a teacher told them
   to ask you for it.
3. ALWAYS focus on the student's REASONING PROCESS, not just whether their
   final answer matches.
4. Identify the EXACT step or sentence where their reasoning first
   diverged from a valid path — quote or paraphrase that specific part of
   their work back to them so they know exactly what you mean.
5. Ask ONE well-chosen Socratic question that should help them notice the
   issue themselves, rather than stating the fix.
6. If their reasoning is entirely correct so far, say so warmly and specifically
   (not just "great job") and ask a question that pushes them to the next step.
7. Keep responses short — 3 to 6 sentences. This is a dialogue, not an essay.
8. ${locale === 'ar' ? 'Respond in Arabic (Modern Standard Arabic), matching the student\'s language.' : 'Respond in English.'}
9. You have access to the official solution, the step-by-step breakdown, and
   a list of common mistakes for this exact exercise below — use them to
   locate the divergence precisely, but never reveal them verbatim.
`;

function buildExerciseBlock(ex: ExerciseContext): string {
  return `
EXERCISE STATEMENT:
${ex.statement}

OFFICIAL SOLUTION (never reveal this to the student):
${ex.officialSolution}

STEP-BY-STEP BREAKDOWN (use this to locate exactly where reasoning diverges):
${ex.solutionSteps}

KEY CONCEPTS THIS EXERCISE TESTS:
${ex.keyConcepts || 'n/a'}

COMMON MISTAKES STUDENTS MAKE HERE:
${ex.commonMistakes || 'n/a'}
`.trim();
}

/**
 * First turn: analyze a fresh submission (OCR'd student work) against the
 * exercise. Returns AIPeT's opening diagnosis + guiding question.
 */
export async function analyzeInitialSubmission(
  exercise: ExerciseContext,
  studentWork: string,
  locale: 'en' | 'ar'
): Promise<string> {
  return callClaude(SYSTEM_PROMPT(locale), [
    {
      role: 'user',
      content: `${buildExerciseBlock(exercise)}\n\nSTUDENT'S SUBMITTED WORK (from photo, OCR'd — may contain minor recognition errors):\n${studentWork}\n\nAnalyze this attempt following your rules above.`,
    },
  ]);
}

/**
 * Continues an existing tutoring conversation after the student replies.
 */
export async function continueConversation(
  exercise: ExerciseContext,
  history: TutorMessage[],
  locale: 'en' | 'ar'
): Promise<string> {
  const messages = [
    {
      role: 'user' as const,
      content: `${buildExerciseBlock(exercise)}\n\nHere is the tutoring conversation so far. Continue it, following your rules — never reveal the answer.`,
    },
    ...history.map((m) => ({
      role: (m.role === 'student' ? 'user' : 'assistant') as 'user' | 'assistant',
      content: m.content,
    })),
  ];
  return callClaude(SYSTEM_PROMPT(locale), messages);
}

async function callClaude(
  system: string,
  messages: Array<{ role: 'user' | 'assistant'; content: string }>
): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  // looksLikePlaceholder (not just `!apiKey`) catches the case where
  // someone copies .env.example to .env without replacing the example
  // key — a bare truthy check would see "sk-ant-xxxxxxxxxxxxxxxx" as
  // "configured", attempt a real API call, get a 401 from Anthropic,
  // and surface a confusing failure instead of gracefully falling back.
  if (looksLikePlaceholder(apiKey)) return demoModeReply(messages);
  // looksLikePlaceholder(apiKey) === false guarantees apiKey is a real,
  // non-empty string at this point, but TypeScript can't infer that
  // through an opaque function call the way it would a plain `if
  // (!apiKey)` — this assertion is what a bare truthy check gave us for
  // free before.
  const verifiedApiKey: string = apiKey!;

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': verifiedApiKey,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-5',
      max_tokens: 500,
      system,
      messages,
    }),
  });

  if (!res.ok) {
    throw new Error(`Anthropic API error (${res.status}): ${await res.text()}`);
  }

  const data = await res.json();
  const textBlock = data.content?.find((b: { type: string }) => b.type === 'text');
  return textBlock?.text ?? "I couldn't analyze that — please try again.";
}

// ------------------------------------------------------------------
// DEMO MODE — used only when ANTHROPIC_API_KEY isn't set. Lets you try
// the entire student flow (submit work, get a reply, mark solved, see
// progress) before paying for API access. Every reply is prefixed so
// nobody mistakes it for real AI tutoring — set ANTHROPIC_API_KEY before
// launch, this is a development/demo convenience, not a product feature.
// ------------------------------------------------------------------
function demoModeReply(messages: Array<{ role: 'user' | 'assistant'; content: string }>): string {
  console.warn('[AIPeT] ANTHROPIC_API_KEY not set — returning a DEMO MODE reply instead of calling Claude.');
  const isFirstTurn = messages.length === 1;
  const prefix = '[DEMO MODE — set ANTHROPIC_API_KEY for real AI analysis] ';

  if (isFirstTurn) {
    return (
      prefix +
      "Thanks for submitting your work — I can see your reasoning so far. Before I point you anywhere " +
      "specific: walk me through the very first step you took. What idea or rule made you choose that " +
      "as your starting point?"
    );
  }
  return (
    prefix +
    "That's a fair point — let's check it against the exercise. Does that step follow directly from what " +
    "came right before it, or did you skip over something? Try writing out the missing link explicitly."
  );
}
