// ------------------------------------------------------------------
// Google Cloud Vision API — turns a photo of handwritten work into text.
// Get a free API key at https://console.cloud.google.com:
//   1. Create a project (or use an existing one)
//   2. APIs & Services -> Library -> enable "Cloud Vision API"
//   3. APIs & Services -> Credentials -> Create Credentials -> API key
// Free tier: 1,000 requests/month, no card required to start. See
// https://cloud.google.com/vision/pricing for current limits.
//
// Honest tradeoff vs. the Mathpix version this replaced: Vision API's
// OCR is general-purpose, not math-specialized — it reads the text but
// doesn't understand LaTeX-style structure, so fractions, exponents, and
// square roots can come out flattened or slightly mangled compared to
// Mathpix's math-aware output. For getting AIPeT actually running without
// up-front cost, this is a solid tradeoff; if math notation accuracy
// becomes a real problem later, Mathpix (or Google's Document AI, which
// has better structure-awareness) is the natural upgrade path — the rest
// of the app doesn't care which OCR provider fills in `studentWork`, so
// swapping again later only touches this one file.
// ------------------------------------------------------------------

interface OcrResult {
  text: string;
  confidence: number;
}

export async function runGoogleVisionOcr(base64DataUrl: string): Promise<OcrResult> {
  const apiKey = process.env.GOOGLE_VISION_API_KEY;

  if (!apiKey) {
    // No OCR configured yet — fail loudly so the caller can fall back to
    // manual transcription instead of silently sending garbage to the tutor.
    throw new Error('GOOGLE_VISION_NOT_CONFIGURED');
  }

  // The Vision API wants raw base64 image bytes, not a data: URL — strip
  // the "data:image/jpeg;base64," prefix the browser's FileReader adds.
  const base64Content = base64DataUrl.includes(',') ? base64DataUrl.split(',')[1] : base64DataUrl;

  const res = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      requests: [
        {
          image: { content: base64Content },
          // DOCUMENT_TEXT_DETECTION (not plain TEXT_DETECTION) is Vision's
          // mode for dense text/handwriting — better fit than the general
          // logo/label-style detection the plain mode is tuned for.
          features: [{ type: 'DOCUMENT_TEXT_DETECTION' }],
        },
      ],
    }),
  });

  if (!res.ok) {
    throw new Error(`Google Vision request failed (${res.status}): ${await res.text()}`);
  }

  const data = await res.json();
  const response = data.responses?.[0];

  if (response?.error) {
    // Vision API returns HTTP 200 with an error object inside for some
    // failure modes (e.g. bad image data) rather than a non-2xx status.
    throw new Error(`Google Vision error: ${response.error.message || 'unknown error'}`);
  }

  const text: string = response?.fullTextAnnotation?.text || '';
  // Vision doesn't return one overall confidence score the way Mathpix
  // did — approximate it by averaging each detected page's confidence,
  // when present, otherwise just report 1 for "got text back" / 0 for none.
  const pages = response?.fullTextAnnotation?.pages ?? [];
  const pageConfidences = pages.map((p: { confidence?: number }) => p.confidence).filter((c: number | undefined) => typeof c === 'number');
  const confidence = pageConfidences.length
    ? pageConfidences.reduce((a: number, b: number) => a + b, 0) / pageConfidences.length
    : text
      ? 1
      : 0;

  return { text, confidence };
}
