import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
});

export async function sendMail(to: string, subject: string, html: string) {
  await transporter.sendMail({
    from: process.env.SMTP_FROM || `AIPeT <${process.env.CONTACT_EMAIL}>`,
    to,
    subject,
    html,
  });
}

export function activationEmailHtml(fullName: string, activationUrl: string) {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: auto;">
      <h2 style="color:#161D3E;">Welcome to AIPeT, ${fullName}</h2>
      <p>Click the button below to activate your AIPeT account. This link expires in 24 hours.</p>
      <p style="text-align:center; margin: 24px 0;">
        <a href="${activationUrl}" style="background:#2FA79B;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;">
          Activate my account
        </a>
      </p>
      <p style="color:#9AA3C0;font-size:12px;">If you didn't request this, you can ignore this email.</p>
    </div>`;
}
