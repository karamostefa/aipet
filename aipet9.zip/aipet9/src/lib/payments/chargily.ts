import crypto from 'crypto';

// ------------------------------------------------------------------
// Chargily Pay — the licensed Algerian gateway that settles EDAHABIA
// and CIB card payments to a CCP/bank account. Docs: https://dev.chargily.com
// You'll need a Chargily merchant account and API keys in .env.
// ------------------------------------------------------------------

const CHARGILY_API_URL = process.env.CHARGILY_API_URL || 'https://pay.chargily.net/api/v2';
const CHARGILY_SECRET_KEY = process.env.CHARGILY_SECRET_KEY!;

interface CreateCheckoutParams {
  amountDzd: number;
  description: string;
  successUrl: string;
  failureUrl: string;
  webhookUrl: string;
  metadata: Record<string, string>;
  customerEmail?: string;
}

export async function createChargilyCheckout(params: CreateCheckoutParams) {
  const res = await fetch(`${CHARGILY_API_URL}/checkouts`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${CHARGILY_SECRET_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: params.amountDzd,
      currency: 'dzd',
      success_url: params.successUrl,
      failure_url: params.failureUrl,
      webhook_endpoint: params.webhookUrl,
      description: params.description,
      customer_email: params.customerEmail,
      metadata: params.metadata,
      // Chargily's checkout page itself lets the customer pick
      // EDAHABIA, CIB, or BaridiMob — we don't have to hardcode one.
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Chargily checkout creation failed (${res.status}): ${body}`);
  }

  return res.json() as Promise<{ id: string; checkout_url: string; status: string }>;
}

/**
 * Verifies the `signature` header Chargily sends with every webhook call,
 * using HMAC-SHA256 over the raw request body. Reject anything that
 * doesn't match — this is what stops attackers from forging fake
 * "payment succeeded" webhooks to unlock AIPeT access for free.
 */
export function verifyChargilySignature(rawBody: string, signatureHeader: string | null): boolean {
  if (!signatureHeader) return false;
  const expected = crypto
    .createHmac('sha256', process.env.CHARGILY_WEBHOOK_SECRET!)
    .update(rawBody)
    .digest('hex');
  // Constant-time comparison prevents timing attacks on the signature check.
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
  } catch {
    return false; // length mismatch etc.
  }
}
