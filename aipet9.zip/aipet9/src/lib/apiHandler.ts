import { NextRequest, NextResponse } from 'next/server';

/**
 * Wraps an API route handler so an unexpected exception (a DB connection
 * error, a missing env var, a third-party API outage — anything) can
 * never surface as a raw, non-JSON error page. That's what "nothing
 * happens" looks like from the browser: `await res.json()` throws a
 * confusing parse error, the request appears to silently vanish, and
 * nothing gets logged anywhere either.
 *
 * Every route in this app is wrapped with this. On any uncaught error:
 *   1. It's logged server-side with full detail (check your server logs —
 *      `vercel logs`, `docker logs`, etc. — search for "[API ERROR]").
 *   2. The client always gets back valid JSON with a clear, safe message
 *      (no stack traces or internals leaked to the browser).
 */
export function withApiHandler(handler: (...args: any[]) => Promise<NextResponse>) {
  return async (...args: any[]): Promise<NextResponse> => {
    try {
      return await handler(...args);
    } catch (err) {
      const req = args[0] as NextRequest | undefined;
      console.error(`[API ERROR] ${req?.method ?? '?'} ${req?.nextUrl?.pathname ?? '?'}:`, err);
      return NextResponse.json(
        { error: 'Something went wrong on our end. Please try again in a moment.' },
        { status: 500 }
      );
    }
  };
}

/**
 * Returns the real error message, but ONLY outside production — safe to
 * spread into a JSON error response for local debugging (e.g. seeing the
 * exact Anthropic/Chargily/Google Vision API error in the browser instead of
 * needing terminal access), without ever leaking internals to real users
 * in production. Usage: `{ error: '...', ...devErrorDetail(err) }`.
 */
export function devErrorDetail(err: unknown): { detail?: string } {
  if (process.env.NODE_ENV === 'production') return {};
  return { detail: err instanceof Error ? err.message : String(err) };
}
