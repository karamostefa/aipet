import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import crypto from 'crypto';

// ------------------------------------------------------------------
// Storage abstraction for uploaded exercise photos.
//
// Ships with a working LOCAL DISK implementation so you can test the
// whole AIPeT flow immediately, with zero extra accounts. Before going
// to production on Vercel, swap this for real object storage — Vercel's
// filesystem is not persistent/shared across instances. The easiest
// swap: Supabase Storage (you likely already have a Supabase project for
// the database). Steps:
//   1. In Supabase dashboard -> Storage -> create a public bucket "aipet-media"
//   2. Replace the body of `uploadImage()` below with a call to
//      `supabase.storage.from('aipet-media').upload(...)` using
//      @supabase/supabase-js and the STORAGE_* env vars already in .env.example
// The rest of the app (submissions) only ever calls `uploadImage()` —
// nothing else needs to change.
// ------------------------------------------------------------------

const UPLOAD_DIR = join(process.cwd(), 'public', 'uploads');

export async function uploadImage(base64DataUrl: string, prefix: string): Promise<string> {
  const match = base64DataUrl.match(/^data:(image\/\w+);base64,(.+)$/);
  if (!match) throw new Error('Invalid image data URL.');
  const [, mimeType, base64] = match;
  const ext = mimeType.split('/')[1] === 'jpeg' ? 'jpg' : mimeType.split('/')[1];
  const filename = `${prefix}-${crypto.randomUUID()}.${ext}`;

  await mkdir(UPLOAD_DIR, { recursive: true });
  await writeFile(join(UPLOAD_DIR, filename), Buffer.from(base64, 'base64'));

  // Publicly reachable because it lives under /public.
  return `/uploads/${filename}`;
}
