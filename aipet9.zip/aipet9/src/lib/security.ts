import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';
import DOMPurify from 'isomorphic-dompurify';
import { z } from 'zod';
import { NextRequest, NextResponse } from 'next/server';

// ------------------------------------------------------------------
// RATE LIMITING — protects login, signup, and submission endpoints from
// brute force / spam / basic DDoS-style abuse.
// Requires Upstash Redis (free tier at launch is plenty).
// ------------------------------------------------------------------
const redis =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
    ? new Redis({
        url: process.env.UPSTASH_REDIS_REST_URL,
        token: process.env.UPSTASH_REDIS_REST_TOKEN,
      })
    : undefined;

// Different budgets for different sensitivity levels.
export const rateLimiters = {
  // Login attempts: 5 per minute per IP — slows credential stuffing.
  login: redis
    ? new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(5, '1 m'), prefix: 'rl:login' })
    : undefined,
  // Public forms (AIPeT signup, submissions): 10 per minute per IP.
  form: redis
    ? new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(10, '1 m'), prefix: 'rl:form' })
    : undefined,
  // General API traffic: 60 per minute per IP.
  api: redis
    ? new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(60, '1 m'), prefix: 'rl:api' })
    : undefined,
};

export function getClientIp(req: NextRequest): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
    req.headers.get('x-real-ip') ||
    '127.0.0.1'
  );
}

/**
 * Call at the top of any route handler that needs abuse protection.
 * Returns a 429 response if the caller is over budget, otherwise null.
 */
export async function checkRateLimit(
  req: NextRequest,
  kind: keyof typeof rateLimiters
): Promise<NextResponse | null> {
  const limiter = rateLimiters[kind];
  if (!limiter) return null; // Redis not configured (e.g. local dev) — skip, don't crash
  const ip = getClientIp(req);
  const { success, remaining } = await limiter.limit(`${kind}:${ip}`);
  if (!success) {
    return NextResponse.json(
      { error: 'Too many requests. Please slow down and try again shortly.' },
      { status: 429, headers: { 'Retry-After': '60' } }
    );
  }
  return null;
}

// ------------------------------------------------------------------
// INPUT SANITIZATION — strips any HTML/script content from free-text
// fields before they ever reach the database. Prisma's parameterized
// queries already prevent SQL injection; this guards against stored
// XSS in fields that get rendered back (e.g. contact messages,
// admin notes shown in the dashboard).
// ------------------------------------------------------------------
export function sanitizeText(input: string): string {
  return DOMPurify.sanitize(input, { ALLOWED_TAGS: [], ALLOWED_ATTR: [] }).trim();
}

// ------------------------------------------------------------------
// VALIDATION SCHEMAS — every public endpoint validates its body
// against one of these before touching the database.
// ------------------------------------------------------------------
export const aipetSignupSchema = z.object({
  fullName: z.string().min(2).max(120),
  email: z.string().email().max(200),
  phone: z.string().min(6).max(30),
});

export const adminLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(200),
});

/**
 * Wraps a handler so any Zod validation failure returns a clean 400
 * instead of leaking stack traces, and so we never trust raw JSON.
 */
export async function parseBody<T>(
  req: NextRequest,
  schema: z.ZodSchema<T>
): Promise<{ data: T } | { error: NextResponse }> {
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return { error: NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 }) };
  }
  const result = schema.safeParse(json);
  if (!result.success) {
    return {
      error: NextResponse.json(
        { error: 'Validation failed.', details: result.error.flatten() },
        { status: 400 }
      ),
    };
  }
  return { data: result.data };
}
