// ------------------------------------------------------------------
// Per-ACCOUNT login lockout, separate from the per-IP rate limiting in
// src/lib/security.ts. Rate limiting stops one machine hammering the
// login endpoint; this stops an attacker trying the same account's
// password from many different IPs (credential stuffing), which rate
// limiting alone never catches since each IP looks fine on its own.
//
// After MAX_FAILED_ATTEMPTS wrong passwords in a row, the account is
// locked for LOCKOUT_MINUTES — a deliberately short window, not a
// permanent ban, so a legitimate student who forgot their password
// doesn't need to email support. Any successful login resets the count.
// ------------------------------------------------------------------

export const MAX_FAILED_ATTEMPTS = 5;
export const LOCKOUT_MINUTES = 15;

interface LockableAccount {
  failedLoginAttempts: number;
  lockedUntil: Date | null;
}

export function isLockedOut(account: LockableAccount): boolean {
  return !!account.lockedUntil && account.lockedUntil > new Date();
}

/** Fields to write back after a failed password check. */
export function nextFailureState(account: LockableAccount): { failedLoginAttempts: number; lockedUntil: Date | null } {
  const attempts = account.failedLoginAttempts + 1;
  if (attempts >= MAX_FAILED_ATTEMPTS) {
    return { failedLoginAttempts: attempts, lockedUntil: new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000) };
  }
  return { failedLoginAttempts: attempts, lockedUntil: null };
}

/** Fields to write back after a successful login. */
export const resetFailureState = { failedLoginAttempts: 0, lockedUntil: null as Date | null };

export function lockedOutMessage(): string {
  return `Too many failed attempts. Please try again in ${LOCKOUT_MINUTES} minutes.`;
}
