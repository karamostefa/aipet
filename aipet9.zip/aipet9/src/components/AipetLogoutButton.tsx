'use client';

import { useRouter } from 'next/navigation';
import type { Locale } from '@/i18n/config';

export default function AipetLogoutButton({ locale }: { locale: Locale }) {
  const router = useRouter();
  async function handleLogout() {
    await fetch('/api/aipet/logout', { method: 'POST' });
    router.push(`/${locale}/aipet`);
    router.refresh();
  }
  return (
    <button onClick={handleLogout} className="rounded-full border border-white/10 px-4 py-2 text-sm text-mist-400 hover:border-red-400 hover:text-red-400">
      {locale === 'ar' ? 'تسجيل الخروج' : 'Log out'}
    </button>
  );
}
