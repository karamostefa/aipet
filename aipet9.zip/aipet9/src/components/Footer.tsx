import type { Locale } from '@/i18n/config';
import type { Dictionary } from '@/i18n/getDictionary';

export default function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  return (
    <footer className="border-t border-white/5 py-10 text-center text-sm text-mist-400">
      <p>{dict.nav.tagline}</p>
      <p className="mt-2 text-xs text-mist-400/70">
        © {new Date().getFullYear()} AIPeT — {locale === 'ar' ? 'المعلم التربوي الذكي' : 'AI Pedagogical Tutor'}
      </p>
    </footer>
  );
}
