'use client';

import { useState } from 'react';
import type { Locale } from '@/i18n/config';
import { PLAN_LABELS, type Plan } from '@/lib/subscriptionPlans';

const PLANS: Plan[] = ['MONTHLY', 'TRIMESTER', 'ANNUAL'];
const SAVINGS: Record<Plan, string | null> = {
  MONTHLY: null,
  TRIMESTER: '~12% off monthly',
  ANNUAL: '~22% off monthly',
};
const SAVINGS_AR: Record<Plan, string | null> = {
  MONTHLY: null,
  TRIMESTER: 'وفّر ~12٪ مقارنة بالشهري',
  ANNUAL: 'وفّر ~22٪ مقارنة بالشهري',
};

export default function SubscribeForm({ locale, prices }: { locale: Locale; prices: Record<Plan, number> }) {
  const [loadingPlan, setLoadingPlan] = useState<Plan | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubscribe(plan: Plan) {
    setLoadingPlan(plan);
    setError(null);
    try {
      const res = await fetch('/api/aipet/subscribe/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan, locale }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong.');
      window.location.href = data.checkoutUrl;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
      setLoadingPlan(null);
    }
  }

  return (
    <div className="mt-8">
      <div className="grid gap-4 sm:grid-cols-3">
        {PLANS.map((plan) => {
          const savings = locale === 'ar' ? SAVINGS_AR[plan] : SAVINGS[plan];
          return (
            <div key={plan} className="card flex flex-col justify-between">
              <div>
                <p className="text-sm text-mist-400">{PLAN_LABELS[plan][locale]}</p>
                <p className="mt-2 text-3xl font-semibold text-white">
                  {prices[plan].toLocaleString('en-US')} <span className="text-base text-mist-400">DZD</span>
                </p>
                {savings && <p className="mt-1 text-xs text-teal-400">{savings}</p>}
              </div>
              <button
                onClick={() => handleSubscribe(plan)}
                disabled={loadingPlan !== null}
                className="btn-primary mt-6 disabled:opacity-60"
              >
                {loadingPlan === plan
                  ? locale === 'ar'
                    ? 'جارٍ التحويل…'
                    : 'Redirecting…'
                  : locale === 'ar'
                    ? 'اشترك الآن'
                    : 'Subscribe'}
              </button>
            </div>
          );
        })}
      </div>
      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}
      <p className="mt-6 text-xs text-mist-400">
        {locale === 'ar'
          ? 'الدفع عبر Chargily — يدعم EDAHABIA وCIB وBaridiMob.'
          : 'Payments processed by Chargily — supports EDAHABIA, CIB, and BaridiMob.'}
      </p>
    </div>
  );
}
