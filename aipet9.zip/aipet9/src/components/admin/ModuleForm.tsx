'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface ModuleFormData {
  id?: string;
  slug: string;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
  order: number;
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
}

const EMPTY: ModuleFormData = { slug: '', nameEn: '', nameAr: '', descriptionEn: '', descriptionAr: '', order: 0, status: 'DRAFT' };

export default function ModuleForm({ initial }: { initial?: ModuleFormData }) {
  const router = useRouter();
  const [form, setForm] = useState<ModuleFormData>(initial ?? EMPTY);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputClass = 'w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500';

  function set<K extends keyof ModuleFormData>(key: K, value: ModuleFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const url = form.id ? `/api/admin/aipet/modules/${form.id}` : '/api/admin/aipet/modules';
      const res = await fetch(url, {
        method: form.id ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed.');
      router.push('/admin/aipet/modules');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Slug (URL-safe id)</label>
          <input required value={form.slug} onChange={(e) => set('slug', e.target.value)} placeholder="mathematics" className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Order (display order)</label>
          <input type="number" value={form.order} onChange={(e) => set('order', Number(e.target.value))} className={inputClass} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Name (EN)</label>
          <input required value={form.nameEn} onChange={(e) => set('nameEn', e.target.value)} placeholder="Mathematics" className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Name (AR)</label>
          <input required dir="rtl" value={form.nameAr} onChange={(e) => set('nameAr', e.target.value)} placeholder="الرياضيات" className={inputClass} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Description (EN, optional)</label>
          <textarea rows={3} value={form.descriptionEn} onChange={(e) => set('descriptionEn', e.target.value)} className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Description (AR, optional)</label>
          <textarea rows={3} dir="rtl" value={form.descriptionAr} onChange={(e) => set('descriptionAr', e.target.value)} className={inputClass} />
        </div>
      </div>
      <div>
        <label className="mb-1 block text-sm text-mist-400">Status</label>
        <select value={form.status} onChange={(e) => set('status', e.target.value as ModuleFormData['status'])} className={inputClass}>
          <option value="DRAFT">Draft (hidden from students)</option>
          <option value="PUBLISHED">Published</option>
          <option value="ARCHIVED">Archived</option>
        </select>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <div className="flex gap-3">
        <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">{loading ? 'Saving…' : 'Save'}</button>
        <button type="button" onClick={() => router.push('/admin/aipet/modules')} className="btn-secondary">Cancel</button>
      </div>
    </form>
  );
}
