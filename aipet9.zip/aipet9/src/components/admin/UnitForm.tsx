'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface ModuleOption { id: string; nameEn: string; }

interface UnitFormData {
  id?: string;
  moduleId: string;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  order: number;
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
}

export default function UnitForm({ modules, initial }: { modules: ModuleOption[]; initial?: UnitFormData }) {
  const router = useRouter();
  const [form, setForm] = useState<UnitFormData>(
    initial ?? { moduleId: modules[0]?.id ?? '', titleEn: '', titleAr: '', descriptionEn: '', descriptionAr: '', order: 0, status: 'DRAFT' }
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputClass = 'w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500';

  function set<K extends keyof UnitFormData>(key: K, value: UnitFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const url = form.id ? `/api/admin/aipet/units/${form.id}` : '/api/admin/aipet/units';
      const res = await fetch(url, {
        method: form.id ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed.');
      router.push('/admin/aipet/units');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl space-y-5">
      <div>
        <label className="mb-1 block text-sm text-mist-400">Module</label>
        <select required value={form.moduleId} onChange={(e) => set('moduleId', e.target.value)} className={inputClass}>
          {modules.map((m) => <option key={m.id} value={m.id}>{m.nameEn}</option>)}
        </select>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Title (EN)</label>
          <input required value={form.titleEn} onChange={(e) => set('titleEn', e.target.value)} placeholder="Sequences" className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Title (AR)</label>
          <input required dir="rtl" value={form.titleAr} onChange={(e) => set('titleAr', e.target.value)} placeholder="المتتاليات" className={inputClass} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Description (EN, optional)</label>
          <textarea rows={3} value={form.descriptionEn} onChange={(e) => set('descriptionEn', e.target.value)} className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Description (AR, optional)</label>
          <textarea rows={3} dir="rtl" value={form.descriptionAr} onChange={(e) => set('descriptionAr', e.target.value)} className={inputClass} />
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm text-mist-400">Order</label>
          <input type="number" value={form.order} onChange={(e) => set('order', Number(e.target.value))} className={inputClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Status</label>
          <select value={form.status} onChange={(e) => set('status', e.target.value as UnitFormData['status'])} className={inputClass}>
            <option value="DRAFT">Draft</option>
            <option value="PUBLISHED">Published</option>
            <option value="ARCHIVED">Archived</option>
          </select>
        </div>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <div className="flex gap-3">
        <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">{loading ? 'Saving…' : 'Save'}</button>
        <button type="button" onClick={() => router.push('/admin/aipet/units')} className="btn-secondary">Cancel</button>
      </div>
    </form>
  );
}
