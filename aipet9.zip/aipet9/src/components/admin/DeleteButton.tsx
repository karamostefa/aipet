'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function DeleteButton({ endpoint }: { endpoint: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleDelete() {
    if (!confirm('Are you sure you want to delete this? This cannot be undone.')) return;
    setLoading(true);
    await fetch(endpoint, { method: 'DELETE' });
    router.refresh();
  }

  return (
    <button onClick={handleDelete} disabled={loading} className="text-red-400 hover:text-red-300 disabled:opacity-50">
      {loading ? 'Deleting…' : 'Delete'}
    </button>
  );
}
