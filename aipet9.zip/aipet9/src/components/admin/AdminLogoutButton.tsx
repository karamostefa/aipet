'use client';

import { useRouter } from 'next/navigation';

export default function AdminLogoutButton() {
  const router = useRouter();
  async function handleLogout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }
  return (
    <button onClick={handleLogout} className="w-full rounded-lg border border-white/10 px-3 py-2 text-sm text-mist-400 transition hover:border-red-400 hover:text-red-400">
      Log out
    </button>
  );
}
