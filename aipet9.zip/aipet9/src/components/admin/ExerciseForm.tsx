'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface UnitOption { id: string; titleEn: string; moduleName: string; }

interface ExerciseFormData {
  id?: string;
  unitId: string;
  number: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  statementEn: string;
  statementAr: string;
  officialSolutionEn: string;
  officialSolutionAr: string;
  solutionStepsEn: string;
  solutionStepsAr: string;
  keyConceptsEn: string;
  keyConceptsAr: string;
  commonMistakesEn: string;
  commonMistakesAr: string;
  status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
}

const EMPTY_BASE = {
  number: 1, difficulty: 'MEDIUM' as const,
  statementEn: '', statementAr: '', officialSolutionEn: '', officialSolutionAr: '',
  solutionStepsEn: '', solutionStepsAr: '', keyConceptsEn: '', keyConceptsAr: '',
  commonMistakesEn: '', commonMistakesAr: '', status: 'DRAFT' as const,
};

export default function ExerciseForm({ units, initial }: { units: UnitOption[]; initial?: ExerciseFormData }) {
  const router = useRouter();
  const [form, setForm] = useState<ExerciseFormData>(initial ?? { unitId: units[0]?.id ?? '', ...EMPTY_BASE });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputClass = 'w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500';

  function set<K extends keyof ExerciseFormData>(key: K, value: ExerciseFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const url = form.id ? `/api/admin/aipet/exercises/${form.id}` : '/api/admin/aipet/exercises';
      const res = await fetch(url, {
        method: form.id ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed.');
      router.push('/admin/aipet/exercises');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-3xl space-y-6">
      <div className="grid gap-5 sm:grid-cols-3">
        <div className="sm:col-span-2">
          <label className="mb-1 block text-sm text-mist-400">Unit</label>
          <select required value={form.unitId} onChange={(e) => set('unitId', e.target.value)} className={inputClass}>
            {units.map((u) => <option key={u.id} value={u.id}>{u.moduleName} — {u.titleEn}</option>)}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm text-mist-400">Exercise #</label>
          <input type="number" min={1} value={form.number} onChange={(e) => set('number', Number(e.target.value))} className={inputClass} />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-mist-400">Difficulty</label>
        <select value={form.difficulty} onChange={(e) => set('difficulty', e.target.value as ExerciseFormData['difficulty'])} className={inputClass}>
          <option value="EASY">Easy</option>
          <option value="MEDIUM">Medium</option>
          <option value="HARD">Hard</option>
        </select>
      </div>

      <fieldset className="rounded-brand border border-white/10 p-4">
        <legend className="px-2 text-sm font-semibold text-white">Statement (what the student sees)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <textarea required rows={4} placeholder="Statement (EN)" value={form.statementEn} onChange={(e) => set('statementEn', e.target.value)} className={inputClass} />
          <textarea required rows={4} dir="rtl" placeholder="نص التمرين (AR)" value={form.statementAr} onChange={(e) => set('statementAr', e.target.value)} className={inputClass} />
        </div>
      </fieldset>

      <fieldset className="rounded-brand border border-gold-500/30 p-4">
        <legend className="px-2 text-sm font-semibold text-gold-500">Official solution (AIPeT sees this — students never do)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <textarea required rows={4} placeholder="Full worked solution (EN)" value={form.officialSolutionEn} onChange={(e) => set('officialSolutionEn', e.target.value)} className={inputClass} />
          <textarea required rows={4} dir="rtl" placeholder="الحل الكامل (AR)" value={form.officialSolutionAr} onChange={(e) => set('officialSolutionAr', e.target.value)} className={inputClass} />
        </div>
      </fieldset>

      <fieldset className="rounded-brand border border-violet-500/30 p-4">
        <legend className="px-2 text-sm font-semibold text-violet-400">Step-by-step breakdown (used to locate exactly where reasoning diverges)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <textarea required rows={4} placeholder="1) ... 2) ... 3) ... (EN)" value={form.solutionStepsEn} onChange={(e) => set('solutionStepsEn', e.target.value)} className={inputClass} />
          <textarea required rows={4} dir="rtl" placeholder="1) ... 2) ... 3) ... (AR)" value={form.solutionStepsAr} onChange={(e) => set('solutionStepsAr', e.target.value)} className={inputClass} />
        </div>
      </fieldset>

      <fieldset className="rounded-brand border border-white/10 p-4">
        <legend className="px-2 text-sm font-semibold text-white">Key concepts (optional, helps AIPeT reference the right theory)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <textarea rows={2} placeholder="Key concepts (EN)" value={form.keyConceptsEn} onChange={(e) => set('keyConceptsEn', e.target.value)} className={inputClass} />
          <textarea rows={2} dir="rtl" placeholder="المفاهيم الأساسية (AR)" value={form.keyConceptsAr} onChange={(e) => set('keyConceptsAr', e.target.value)} className={inputClass} />
        </div>
      </fieldset>

      <fieldset className="rounded-brand border border-white/10 p-4">
        <legend className="px-2 text-sm font-semibold text-white">Common mistakes (optional, helps AIPeT recognize typical errors faster)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <textarea rows={3} placeholder="Common mistakes (EN)" value={form.commonMistakesEn} onChange={(e) => set('commonMistakesEn', e.target.value)} className={inputClass} />
          <textarea rows={3} dir="rtl" placeholder="الأخطاء الشائعة (AR)" value={form.commonMistakesAr} onChange={(e) => set('commonMistakesAr', e.target.value)} className={inputClass} />
        </div>
      </fieldset>

      <div>
        <label className="mb-1 block text-sm text-mist-400">Status</label>
        <select value={form.status} onChange={(e) => set('status', e.target.value as ExerciseFormData['status'])} className={inputClass}>
          <option value="DRAFT">Draft (hidden from students)</option>
          <option value="PUBLISHED">Published</option>
          <option value="ARCHIVED">Archived</option>
        </select>
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}
      <div className="flex gap-3">
        <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">{loading ? 'Saving…' : 'Save'}</button>
        <button type="button" onClick={() => router.push('/admin/aipet/exercises')} className="btn-secondary">Cancel</button>
      </div>
    </form>
  );
}
