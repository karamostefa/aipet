'use client';

import { useState } from 'react';
import type { Dictionary } from '@/i18n/getDictionary';

export default function AipetSignupForm({ dict }: { dict: Dictionary }) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/aipet/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, email, phone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || dict.common.error);
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : dict.common.error);
    } finally {
      setLoading(false);
    }
  }

  if (done) {
    return (
      <p className="mt-6 rounded-lg border border-teal-500/30 bg-teal-500/10 p-4 text-teal-300">
        {dict.aipet.activationNote}
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-6 space-y-5">
      <div>
        <label className="mb-1 block text-sm text-mist-400">{dict.aipet.fullName}</label>
        <input required value={fullName} onChange={(e) => setFullName(e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
      </div>
      <div>
        <label className="mb-1 block text-sm text-mist-400">{dict.aipet.email}</label>
        <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
      </div>
      <div>
        <label className="mb-1 block text-sm text-mist-400">{dict.aipet.phone}</label>
        <input required value={phone} onChange={(e) => setPhone(e.target.value)}
          className="w-full rounded-lg border border-white/10 bg-ink-900 px-4 py-2.5 text-white outline-none focus:border-teal-500" />
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
        {loading ? dict.common.loading : dict.aipet.createAccount}
      </button>
    </form>
  );
}
